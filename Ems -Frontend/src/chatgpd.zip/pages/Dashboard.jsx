import { useEffect, useState } from "react";
import axios from "axios";
import DashboardCard from "../components/DashboardCard";
import "./Dashboard.css";

function Dashboard() {

    const [dashboardData, setDashboardData] = useState({
        totalEmployees: 0,
        pendingLeaves: 0,
        approvedLeaves: 0,
        rejectedLeaves: 0
    });

    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchDashboardData();
        setTimeout(() => setLoading(false), 500);
    }, []);

    const fetchDashboardData = async () => {

        try {

            const response = await axios.get(
                "http://localhost:9090/api/dashboard"
            );

            setDashboardData(response.data);

        } catch (error) {

            console.error("Dashboard Error:", error);

        }

    };

    if (loading) {
        return (
            <div className="loading-container">
                <div className="spinner-border loading-spinner" role="status"></div>
                <p className="loading-text">Loading Dashboard...</p>
            </div>
        );
    }

    return (

        <div className="dashboard-page-container">

            <div className="dashboard-page-header">

                <h1 className="dashboard-title">Dashboard</h1>

                <p className="dashboard-subtitle">Welcome to your attendance & leave management system</p>

            </div>

            <div className="dashboard-card-grid">

                <div className="dashboard-card-wrapper">

                    <DashboardCard
                        title="Total Employees"
                        value={dashboardData.totalEmployees}
                        icon="👥"
                        bgColor="#3b82f6"
                        statusType="employees"
                    />

                </div>

                <div className="dashboard-card-wrapper">

                    <DashboardCard
                        title="Pending Leaves"
                        value={dashboardData.pendingLeaves}
                        icon="📝"
                        bgColor="#f59e0b"
                        statusType="pending"
                    />

                </div>

                <div className="dashboard-card-wrapper">

                    <DashboardCard
                        title="Approved Leaves"
                        value={dashboardData.approvedLeaves}
                        icon="✅"
                        bgColor="#10b981"
                        statusType="approved"
                    />

                </div>

                <div className="dashboard-card-wrapper">

                    <DashboardCard
                        title="Rejected Leaves"
                        value={dashboardData.rejectedLeaves}
                        icon="❌"
                        bgColor="#ef4444"
                        statusType="rejected"
                    />

                </div>

            </div>

        </div>

    );

}

export default Dashboard;