package com.cms.employeemanagement.service;

import java.util.List;

import com.cms.employeemanagement.entity.Book;

public interface BookService {

    Book addBook(Book book);

    List<Book> getAllBooks();

    Book getBookById(Long id);

    Book updateBook(Long id, Book book);

    void deleteBook(Long id);

    Book getBookByBarcode(String barcode);
}