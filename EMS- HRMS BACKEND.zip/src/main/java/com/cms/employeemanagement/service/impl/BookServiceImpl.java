package com.cms.employeemanagement.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.cms.employeemanagement.entity.Book;
import com.cms.employeemanagement.repository.BookRepository;
import com.cms.employeemanagement.service.BookService;

@Service
public class BookServiceImpl implements BookService {

    private static final Logger logger =
            LoggerFactory.getLogger(BookServiceImpl.class);

    private final BookRepository bookRepository;

    public BookServiceImpl(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // =========================
    // ADD BOOK
    // =========================
    @Override
    public Book addBook(Book book) {

        logger.info("Adding new book. Barcode: {}", book.getBarcode());

        if (bookRepository.existsByBarcode(book.getBarcode())) {

            logger.error(
                    "Book already exists with barcode: {}",
                    book.getBarcode()
            );

            throw new RuntimeException(
                    "Book with this barcode already exists"
            );
        }

        Book savedBook = bookRepository.save(book);

        logger.info(
                "Book added successfully. Book ID: {}",
                savedBook.getId()
        );

        return savedBook;
    }

    // =========================
    // GET ALL BOOKS
    // =========================
    @Override
    public List<Book> getAllBooks() {

        logger.info("Fetching all books");

        List<Book> books = bookRepository.findAll();

        logger.info(
                "Successfully fetched {} books",
                books.size()
        );

        return books;
    }

    // =========================
    // GET BOOK BY ID
    // =========================
    @Override
    public Book getBookById(Long id) {

        logger.info("Fetching book with ID: {}", id);

        Book book = bookRepository.findById(id)
                .orElseThrow(() -> {

                    logger.error(
                            "Book not found with ID: {}",
                            id
                    );

                    return new RuntimeException(
                            "Book not found with ID: " + id
                    );
                });

        logger.info(
                "Book found successfully. ID: {}",
                id
        );

        return book;
    }

    // =========================
    // UPDATE BOOK
    // =========================
    @Override
    public Book updateBook(Long id, Book book) {

        logger.info("Updating book with ID: {}", id);

        Book existingBook = getBookById(id);

        existingBook.setTitle(book.getTitle());
        existingBook.setAuthor(book.getAuthor());
        existingBook.setIsbn(book.getIsbn());
        existingBook.setCategory(book.getCategory());

        Book updatedBook = bookRepository.save(existingBook);

        logger.info(
                "Book updated successfully. ID: {}",
                id
        );

        return updatedBook;
    }

    // =========================
    // DELETE BOOK
    // =========================
    @Override
    public void deleteBook(Long id) {

        logger.info("Deleting book with ID: {}", id);

        Book existingBook = getBookById(id);

        bookRepository.delete(existingBook);

        logger.info(
                "Book deleted successfully. ID: {}",
                id
        );
    }

    // =========================
    // GET BOOK BY BARCODE
    // =========================
    @Override
    public Book getBookByBarcode(String barcode) {

        logger.info(
                "Searching book with barcode: {}",
                barcode
        );

        Book book = bookRepository.findByBarcode(barcode)
                .orElseThrow(() -> {

                    logger.error(
                            "Book not found with barcode: {}",
                            barcode
                    );

                    return new RuntimeException(
                            "Book not found with barcode: " + barcode
                    );
                });

        logger.info(
                "Book found successfully with barcode: {}",
                barcode
        );

        return book;
    }
}