package com.cms.employeemanagement.service;

import java.util.List;

import com.cms.employeemanagement.entity.BookTransaction;

public interface BookTransactionService {

    BookTransaction issueBook(Long employeeId, String barcode);

    BookTransaction returnBook(String barcode);

    List<BookTransaction> getAllTransactions();

    List<BookTransaction> getEmployeeTransactions(Long employeeId);

}