package com.cms.employeemanagement.service.impl;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.cms.employeemanagement.dto.EmployeeDto;
import com.cms.employeemanagement.entity.Employee;
import com.cms.employeemanagement.entity.Role;
import com.cms.employeemanagement.entity.User;
import com.cms.employeemanagement.repository.EmployeeRepository;
import com.cms.employeemanagement.repository.UserRepository;
import com.cms.employeemanagement.service.EmployeeService;
import com.cms.employeemanagement.util.CsvHelper;

@Service
@Transactional
public class EmployeeServiceImpl
        implements EmployeeService {


    @Autowired
    private EmployeeRepository employeeRepository;


    @Autowired
    private UserRepository userRepository;


    @Autowired
    private PasswordEncoder passwordEncoder;


    // =========================================================
    // Generate QR Token
    // =========================================================

    private String generateQrToken() {

        return UUID.randomUUID()
                .toString()
                .replace("-", "");
    }


    // =========================================================
    // Ensure Employee Has QR Token
    // =========================================================

    private void ensureQrToken(Employee employee) {

        if (employee.getQrToken() == null ||
                employee.getQrToken().trim().isEmpty()) {

            employee.setQrToken(
                    generateQrToken()
            );

            employeeRepository.save(employee);
        }
    }


    // =========================================================
    // Save Employee
    // =========================================================

    @Override
    public Employee saveEmployee(EmployeeDto dto) {


        // Check duplicate employee email

        if (employeeRepository
                .existsByEmail(dto.getEmail())) {

            throw new RuntimeException(
                    "Employee email already exists."
            );
        }


        Employee employee = new Employee();


        BeanUtils.copyProperties(
                dto,
                employee
        );


        // Generate permanent QR token

        employee.setQrToken(
                generateQrToken()
        );


        employee.setCasualLeave(12);

        employee.setSickLeave(8);

        employee.setEarnedLeave(15);


        Employee savedEmployee =
                employeeRepository.save(employee);


        // Create employee login account

        if (!userRepository
                .findByEmail(dto.getEmail())
                .isPresent()) {


            User user = new User();


            user.setEmail(
                    dto.getEmail()
            );


            user.setPassword(
                    passwordEncoder.encode(
                            "employee123"
                    )
            );


            user.setRole(
                    Role.ROLE_EMPLOYEE
            );


            user.setActive(true);


            userRepository.save(user);
        }


        return savedEmployee;
    }


    // =========================================================
    // Update Employee
    // =========================================================

    @Override
    public Employee updateEmployee(
            Long id,
            EmployeeDto dto) {


        Employee employee =
                employeeRepository
                        .findById(id)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Employee not found"
                                )
                        );


        // Make sure existing employee
        // has a QR token

        ensureQrToken(employee);


        String oldEmail =
                employee.getEmail();


        BeanUtils.copyProperties(
                dto,
                employee,
                "id",
                "qrToken"
        );


        // Preserve the existing QR token

        Employee updatedEmployee =
                employeeRepository.save(
                        employee
                );


        // Update login email if employee email changed

        if (!oldEmail.equals(dto.getEmail())) {


            Optional<User> optionalUser =
                    userRepository
                            .findByEmail(oldEmail);


            if (optionalUser.isPresent()) {


                User user =
                        optionalUser.get();


                user.setEmail(
                        dto.getEmail()
                );


                userRepository.save(user);
            }
        }


        return updatedEmployee;
    }


    // =========================================================
    // Delete Employee
    // =========================================================

    @Override
    public void deleteEmployee(Long id) {


        Employee employee =
                employeeRepository
                        .findById(id)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Employee not found"
                                )
                        );


        userRepository
                .findByEmail(
                        employee.getEmail()
                )
                .ifPresent(
                        userRepository::delete
                );


        employeeRepository.delete(employee);
    }


    // =========================================================
    // Get Employee By ID
    // =========================================================

    @Override
    public Employee getEmployeeById(Long id) {


        Employee employee =
                employeeRepository
                        .findById(id)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Employee not found"
                                )
                        );


        ensureQrToken(employee);


        return employee;
    }


    // =========================================================
    // Get Employee By Email
    // =========================================================

    @Override
    public Employee getEmployeeByEmail(
            String email) {


        if (email == null ||
                email.trim().isEmpty()) {

            throw new RuntimeException(
                    "Employee email is required."
            );
        }


        Employee employee =
                employeeRepository
                        .findByEmail(
                                email.trim()
                        )
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Employee not found with email: "
                                                + email
                                )
                        );


        ensureQrToken(employee);


        return employee;
    }


    // =========================================================
    // Get Employee By QR Token
    // =========================================================

    @Override
    public Employee getEmployeeByQrToken(
            String qrToken) {


        if (qrToken == null ||
                qrToken.trim().isEmpty()) {

            throw new RuntimeException(
                    "QR token is required."
            );
        }


        Employee employee =
                employeeRepository
                        .findByQrToken(
                                qrToken.trim()
                        )
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Invalid employee QR code."
                                )
                        );


        return employee;
    }


    // =========================================================
    // Get All Employees
    // =========================================================

    @Override
    public List<Employee> getAllEmployees() {


        List<Employee> employees =
                employeeRepository.findAll();


        employees.forEach(
                this::ensureQrToken
        );


        return employees;
    }


    // =========================================================
    // Get Employees Pagination
    // =========================================================

    @Override
    public Page<Employee> getEmployees(
            int page,
            int size) {


        Page<Employee> employees =
                employeeRepository.findAll(
                        PageRequest.of(
                                page,
                                size
                        )
                );


        employees
                .getContent()
                .forEach(
                        this::ensureQrToken
                );


        return employees;
    }


    // =========================================================
    // Refresh Employees
    // =========================================================

    @Override
    public List<Employee> refreshEmployees() {


        List<Employee> employees =
                employeeRepository.findAll();


        employees.forEach(
                this::ensureQrToken
        );


        return employees;
    }


    // =========================================================
    // Upload CSV
    // =========================================================

    @Override
    public String uploadCsv(
            MultipartFile file)
            throws IOException {


        List<Employee> employees =
                CsvHelper.csvToEmployees(file);


        for (Employee employee : employees) {


            employee.setCasualLeave(12);

            employee.setSickLeave(8);

            employee.setEarnedLeave(15);


            // Generate QR token for CSV employee

            if (employee.getQrToken() == null ||
                    employee.getQrToken()
                            .trim()
                            .isEmpty()) {

                employee.setQrToken(
                        generateQrToken()
                );
            }


            employeeRepository.save(
                    employee
            );


            // Create employee login

            if (!userRepository
                    .findByEmail(
                            employee.getEmail()
                    )
                    .isPresent()) {


                User user =
                        new User();


                user.setEmail(
                        employee.getEmail()
                );


                user.setPassword(
                        passwordEncoder.encode(
                                "employee123"
                        )
                );


                user.setRole(
                        Role.ROLE_EMPLOYEE
                );


                user.setActive(true);


                userRepository.save(
                        user
                );
            }
        }


        return "CSV Uploaded Successfully";
    }
}