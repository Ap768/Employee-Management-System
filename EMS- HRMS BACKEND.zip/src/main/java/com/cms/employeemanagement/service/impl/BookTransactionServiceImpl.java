package com.cms.employeemanagement.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.employeemanagement.entity.Book;
import com.cms.employeemanagement.entity.BookStatus;
import com.cms.employeemanagement.entity.BookTransaction;
import com.cms.employeemanagement.entity.Employee;
import com.cms.employeemanagement.entity.TransactionStatus;
import com.cms.employeemanagement.repository.BookRepository;
import com.cms.employeemanagement.repository.BookTransactionRepository;
import com.cms.employeemanagement.repository.EmployeeRepository;
import com.cms.employeemanagement.service.BookTransactionService;

@Service
public class BookTransactionServiceImpl implements BookTransactionService {

    private final BookTransactionRepository transactionRepository;
    private final BookRepository bookRepository;
    private final EmployeeRepository employeeRepository;

    public BookTransactionServiceImpl(
            BookTransactionRepository transactionRepository,
            BookRepository bookRepository,
            EmployeeRepository employeeRepository) {

        this.transactionRepository = transactionRepository;
        this.bookRepository = bookRepository;
        this.employeeRepository = employeeRepository;
    }

    @Override
    @Transactional
    public BookTransaction issueBook(Long employeeId, String barcode) {

        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Employee not found with ID: " + employeeId));

        Book book = bookRepository.findByBarcode(barcode)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Book not found with barcode: " + barcode));

        if (book.getStatus() == BookStatus.ISSUED) {
            throw new RuntimeException(
                    "Book is already issued: " + barcode);
        }

        BookTransaction transaction = new BookTransaction();

        transaction.setBook(book);
        transaction.setEmployee(employee);
        transaction.setIssueDate(LocalDateTime.now());
        transaction.setStatus(TransactionStatus.ISSUED);

        book.setStatus(BookStatus.ISSUED);
        bookRepository.save(book);

        return transactionRepository.save(transaction);
    }

    @Override
    @Transactional
    public BookTransaction returnBook(String barcode) {

        Book book = bookRepository.findByBarcode(barcode)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Book not found with barcode: " + barcode));

        if (book.getStatus() == BookStatus.AVAILABLE) {
            throw new RuntimeException(
                    "Book is already available and has not been issued.");
        }

        BookTransaction transaction =
                transactionRepository
                        .findByBookAndStatus(
                                book,
                                TransactionStatus.ISSUED)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Active issue transaction not found for book: "
                                                + barcode));

        transaction.setReturnDate(LocalDateTime.now());
        transaction.setStatus(TransactionStatus.RETURNED);

        book.setStatus(BookStatus.AVAILABLE);
        bookRepository.save(book);

        return transactionRepository.save(transaction);
    }

    @Override
    public List<BookTransaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    @Override
    public List<BookTransaction> getEmployeeTransactions(Long employeeId) {

        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Employee not found with ID: " + employeeId));

        return transactionRepository.findByEmployee(employee);
    }
}