package com.cms.employeemanagement.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cms.employeemanagement.entity.Book;
import com.cms.employeemanagement.entity.BookTransaction;
import com.cms.employeemanagement.entity.Employee;
import com.cms.employeemanagement.entity.TransactionStatus;

@Repository
public interface BookTransactionRepository
        extends JpaRepository<BookTransaction, Long> {

    Optional<BookTransaction> findByBookAndStatus(
            Book book,
            TransactionStatus status);

    List<BookTransaction> findByEmployee(Employee employee);

    List<BookTransaction> findByBook(Book book);
}