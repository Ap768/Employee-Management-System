package com.cms.employeemanagement.exception;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger =
            LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // ==========================================
    // RUNTIME EXCEPTION
    // ==========================================
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<String> handleRuntimeException(
            RuntimeException ex) {

        logger.error(
                "Runtime exception occurred: {}",
                ex.getMessage(),
                ex
        );

        return new ResponseEntity<>(
                ex.getMessage(),
                HttpStatus.BAD_REQUEST
        );
    }

    // ==========================================
    // VALIDATION EXCEPTION
    // ==========================================
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationException(
            MethodArgumentNotValidException ex) {

        logger.error(
                "Validation error occurred while processing request"
        );

        Map<String, String> errors = new HashMap<>();

        for (FieldError error :
                ex.getBindingResult().getFieldErrors()) {

            logger.error(
                    "Validation error - Field: {}, Message: {}",
                    error.getField(),
                    error.getDefaultMessage()
            );

            errors.put(
                    error.getField(),
                    error.getDefaultMessage()
            );
        }

        return new ResponseEntity<>(
                errors,
                HttpStatus.BAD_REQUEST
        );
    }

    // ==========================================
    // GENERAL / UNEXPECTED EXCEPTION
    // ==========================================
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGeneralException(
            Exception ex) {

        logger.error(
                "Unexpected error occurred: {}",
                ex.getMessage(),
                ex
        );

        return new ResponseEntity<>(
                "An unexpected error occurred. Please contact the administrator.",
                HttpStatus.INTERNAL_SERVER_ERROR
        );
    }
}