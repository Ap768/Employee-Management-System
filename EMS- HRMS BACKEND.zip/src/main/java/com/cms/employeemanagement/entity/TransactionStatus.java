package com.cms.employeemanagement.entity;

public enum TransactionStatus {
    ISSUED,
    RETURNED
}