package com.cms.employeemanagement.entity;

public enum BookStatus {

    AVAILABLE,
    ISSUED
}