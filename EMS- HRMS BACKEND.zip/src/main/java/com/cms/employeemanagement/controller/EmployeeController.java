package com.cms.employeemanagement.controller;

import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import com.cms.employeemanagement.dto.EmployeeDto;
import com.cms.employeemanagement.entity.Employee;
import com.cms.employeemanagement.service.EmployeeService;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;


    // =========================================================
    // EMPLOYEE SELF PROFILE
    // =========================================================

    /*
     * Employee can access ONLY his/her own profile.
     *
     * Frontend:
     * GET /api/employees/my-profile
     */
    @PreAuthorize("hasRole('EMPLOYEE')")
    @GetMapping("/my-profile")
    public ResponseEntity<Employee> getMyProfile(
            Authentication authentication) {

        String email = authentication.getName();

        Employee employee =
                employeeService.getEmployeeByEmail(email);

        return ResponseEntity.ok(employee);
    }


    // =========================================================
    // GET EMPLOYEE BY QR TOKEN
    // =========================================================

    /*
     * Used by Admin/HR scanner.
     *
     * Admin/HR scans employee's permanent QR.
     */
    @PreAuthorize("hasAnyRole('ADMIN', 'HR')")
    @GetMapping("/qr/{qrToken}")
    public ResponseEntity<Employee> getEmployeeByQrToken(
            @PathVariable String qrToken) {

        return ResponseEntity.ok(
                employeeService.getEmployeeByQrToken(qrToken)
        );
    }


    // =========================================================
    // GET EMPLOYEE BY ID
    // =========================================================

    @PreAuthorize("hasAnyRole('ADMIN', 'HR')")
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                employeeService.getEmployeeById(id)
        );
    }


    // =========================================================
    // ADD EMPLOYEE
    // =========================================================

    @PreAuthorize("hasAnyRole('ADMIN', 'HR')")
    @PostMapping
    public ResponseEntity<Employee> saveEmployee(
            @Valid @RequestBody EmployeeDto employeeDto) {

        return ResponseEntity.ok(
                employeeService.saveEmployee(employeeDto)
        );
    }


    // =========================================================
    // UPDATE EMPLOYEE
    // =========================================================

    @PreAuthorize("hasAnyRole('ADMIN', 'HR')")
    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(
            @PathVariable Long id,
            @Valid @RequestBody EmployeeDto employeeDto) {

        return ResponseEntity.ok(
                employeeService.updateEmployee(id, employeeDto)
        );
    }


    // =========================================================
    // DELETE EMPLOYEE
    // =========================================================

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEmployee(
            @PathVariable Long id) {

        employeeService.deleteEmployee(id);

        return ResponseEntity.ok(
                "Employee Deleted Successfully"
        );
    }


    // =========================================================
    // REFRESH EMPLOYEES
    // =========================================================

    @PreAuthorize("hasAnyRole('ADMIN', 'HR')")
    @GetMapping("/refresh")
    public ResponseEntity<List<Employee>> refreshEmployees() {

        return ResponseEntity.ok(
                employeeService.refreshEmployees()
        );
    }


    // =========================================================
    // PAGINATION
    // =========================================================

    @PreAuthorize("hasAnyRole('ADMIN', 'HR')")
    @GetMapping("/pagination")
    public ResponseEntity<Page<Employee>> getEmployees(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size) {

        return ResponseEntity.ok(
                employeeService.getEmployees(page, size)
        );
    }


    // =========================================================
    // CSV UPLOAD
    // =========================================================

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/upload")
    public ResponseEntity<String> uploadCsv(
            @RequestParam("file") MultipartFile file)
            throws IOException {

        return ResponseEntity.ok(
                employeeService.uploadCsv(file)
        );
    }
}