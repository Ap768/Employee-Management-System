package com.cms.employeemanagement.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cms.employeemanagement.entity.BookTransaction;
import com.cms.employeemanagement.service.BookTransactionService;

@RestController
@RequestMapping("/api/book-transactions")
@CrossOrigin
public class BookTransactionController {

    private final BookTransactionService transactionService;

    public BookTransactionController(
            BookTransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @PostMapping("/issue")
    public ResponseEntity<BookTransaction> issueBook(
            @RequestParam Long employeeId,
            @RequestParam String barcode) {

        return ResponseEntity.ok(
                transactionService.issueBook(employeeId, barcode));
    }

    @PostMapping("/return")
    public ResponseEntity<BookTransaction> returnBook(
            @RequestParam String barcode) {

        return ResponseEntity.ok(
                transactionService.returnBook(barcode));
    }

    @GetMapping																																							
    public ResponseEntity<List<BookTransaction>> getAllTransactions() {

        return ResponseEntity.ok(
                transactionService.getAllTransactions());
    }

    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<BookTransaction>> getEmployeeTransactions(
            @PathVariable Long employeeId) {

        return ResponseEntity.ok(
                transactionService.getEmployeeTransactions(employeeId));
    }
}