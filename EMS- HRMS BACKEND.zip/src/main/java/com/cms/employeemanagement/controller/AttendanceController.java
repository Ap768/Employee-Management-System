package com.cms.employeemanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cms.employeemanagement.dto.AttendanceDto;
import com.cms.employeemanagement.dto.AttendanceQrScanRequest;
import com.cms.employeemanagement.dto.QrAttendanceRequest;
import com.cms.employeemanagement.service.AttendanceService;

@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {

    @Autowired
    private AttendanceService attendanceService;


    // =====================================================
    // NORMAL EMPLOYEE CHECK-IN
    // =====================================================

    @PostMapping("/checkin/{email}")
    public AttendanceDto checkIn(
            @PathVariable String email) {

        return attendanceService.checkIn(email);
    }


    // =====================================================
    // NORMAL EMPLOYEE CHECK-OUT
    // =====================================================

    @PutMapping("/checkout/{email}")
    public AttendanceDto checkOut(
            @PathVariable String email) {

        return attendanceService.checkOut(email);
    }


    // =====================================================
    // OLD QR ATTENDANCE
    // =====================================================

    @PostMapping("/qr-punch")
    public AttendanceDto qrPunch(
            @RequestBody QrAttendanceRequest request) {

        return attendanceService.qrPunch(request);
    }


    // =====================================================
    // NEW PERMANENT EMPLOYEE QR SCANNER
    // ADMIN / HR ONLY
    // =====================================================

    @PreAuthorize("hasAnyRole('ADMIN', 'HR')")
    @PostMapping("/scan")
    public ResponseEntity<AttendanceDto> scanEmployeeQr(
            @RequestBody AttendanceQrScanRequest request) {

        if (request == null ||
            request.getQrToken() == null ||
            request.getQrToken().trim().isEmpty()) {

            throw new RuntimeException("QR token is missing.");
        }

        return ResponseEntity.ok(
                attendanceService.scanEmployeeQr(
                        request.getQrToken()
                )
        );
    }


    // =====================================================
    // TODAY ATTENDANCE
    // =====================================================

    @GetMapping("/today/{email}")
    public AttendanceDto getTodayAttendance(
            @PathVariable String email) {

        return attendanceService.getTodayAttendance(email);
    }


    // =====================================================
    // ATTENDANCE HISTORY
    // =====================================================

    @GetMapping("/history/{email}")
    public List<AttendanceDto> getAttendanceHistory(
            @PathVariable String email) {

        return attendanceService.getAttendanceHistory(email);
    }


    // =====================================================
    // ALL ATTENDANCE
    // =====================================================

    @GetMapping
    public List<AttendanceDto> getAllAttendance() {

        return attendanceService.getAllAttendance();
    }


    // =====================================================
    // ATTENDANCE BY DATE
    // =====================================================

    @GetMapping("/date/{email}/{date}")
    public AttendanceDto getAttendanceByDate(
            @PathVariable String email,
            @PathVariable String date) {

        return attendanceService.getAttendanceByDate(
                email,
                date
        );
    }


    // =====================================================
    // MANAGEMENT ATTENDANCE BY DATE
    // =====================================================

    @GetMapping("/management/{date}")
    public List<AttendanceDto> getAttendanceForAllEmployeesByDate(
            @PathVariable String date) {

        return attendanceService
                .getAttendanceForAllEmployeesByDate(date);
    }
}