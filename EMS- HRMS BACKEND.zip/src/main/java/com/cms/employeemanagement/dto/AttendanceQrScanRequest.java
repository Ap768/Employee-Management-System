package com.cms.employeemanagement.dto;

public class AttendanceQrScanRequest {

    private String qrToken;

    public AttendanceQrScanRequest() {
    }

    public String getQrToken() {
        return qrToken;
    }

    public void setQrToken(String qrToken) {
        this.qrToken = qrToken;
    }
}