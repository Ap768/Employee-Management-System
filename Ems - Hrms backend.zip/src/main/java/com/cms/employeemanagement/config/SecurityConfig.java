package com.cms.employeemanagement.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.http.HttpMethod;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.cms.employeemanagement.security.CustomUserDetailsService;
import com.cms.employeemanagement.security.JwtAuthenticationFilter;

@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;


    // =========================================================
    // PASSWORD ENCODER
    // =========================================================

    @Bean
    public PasswordEncoder passwordEncoder() {

        return new BCryptPasswordEncoder();
    }


    // =========================================================
    // AUTHENTICATION MANAGER
    // =========================================================

    @Bean
    public AuthenticationManager authenticationManager(
            HttpSecurity http) throws Exception {

        AuthenticationManagerBuilder builder =
                http.getSharedObject(
                        AuthenticationManagerBuilder.class
                );

        builder
            .userDetailsService(userDetailsService)
            .passwordEncoder(passwordEncoder());

        return builder.build();
    }


    // =========================================================
    // SECURITY FILTER CHAIN
    // =========================================================

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http) throws Exception {

        http

            // -------------------------------------------------
            // CORS
            // -------------------------------------------------

            .cors()

            .and()

            // -------------------------------------------------
            // CSRF
            // -------------------------------------------------

            .csrf()
            .disable()

            // -------------------------------------------------
            // H2 CONSOLE
            // -------------------------------------------------

            .headers()
            .frameOptions()
            .disable()

            .and()

            // -------------------------------------------------
            // SESSION
            // -------------------------------------------------

            .sessionManagement()
            .sessionCreationPolicy(
                    SessionCreationPolicy.STATELESS
            )

            .and()

            // -------------------------------------------------
            // AUTHORIZATION
            // -------------------------------------------------

            .authorizeRequests()


            // =================================================
            // PUBLIC LOGIN APIs
            // =================================================

            .antMatchers(
                    "/api/users/login",
                    "/api/users/verify-otp",
                    "/api/users/forgot-password"
            )
            .permitAll()


            // =================================================
            // OLD QR PUNCH API
            // =================================================

            .antMatchers(
                    HttpMethod.POST,
                    "/api/attendance/qr-punch"
            )
            .permitAll()


            // =================================================
            // NEW PERMANENT EMPLOYEE QR SCANNER
            // ADMIN / HR ONLY
            // =================================================

            .antMatchers(
                    HttpMethod.POST,
                    "/api/attendance/scan"
            )
            .hasAnyRole("ADMIN", "HR")


            // =================================================
            // H2
            // =================================================

            .antMatchers(
                    "/h2-console/**"
            )
            .permitAll()


            // =================================================
            // SWAGGER
            // =================================================

            .antMatchers(
                    "/swagger-ui/**",
                    "/swagger-resources/**",
                    "/v2/api-docs",
                    "/webjars/**"
            )
            .permitAll()


            // =================================================
            // EMPLOYEE SELF PROFILE
            // IMPORTANT:
            // THIS MUST COME BEFORE /api/employees/**
            // =================================================

            .antMatchers(
                    HttpMethod.GET,
                    "/api/employees/my-profile"
            )
            .hasRole("EMPLOYEE")


            // =================================================
            // EMPLOYEE QR LOOKUP
            // =================================================

            .antMatchers(
                    HttpMethod.GET,
                    "/api/employees/qr/**"
            )
            .hasAnyRole("ADMIN", "HR")


            // =================================================
            // DELETE EMPLOYEE
            // =================================================

            .antMatchers(
                    HttpMethod.DELETE,
                    "/api/employees/**"
            )
            .hasRole("ADMIN")


            // =================================================
            // UPLOAD EMPLOYEES
            // =================================================

            .antMatchers(
                    HttpMethod.POST,
                    "/api/employees/upload"
            )
            .hasRole("ADMIN")


            // =================================================
            // OTHER EMPLOYEE APIs
            // =================================================

            .antMatchers(
                    "/api/employees/**"
            )
            .hasAnyRole("ADMIN", "HR")


            // =================================================
            // EVERYTHING ELSE
            // =================================================

            .anyRequest()
            .authenticated()

            .and()

            // =================================================
            // JWT FILTER
            // =================================================

            .addFilterBefore(
                    jwtAuthenticationFilter,
                    UsernamePasswordAuthenticationFilter.class
            );

        return http.build();
    }
}