package com.cms.employeemanagement.service.impl;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.employeemanagement.dto.AttendanceDto;
import com.cms.employeemanagement.dto.QrAttendanceRequest;
import com.cms.employeemanagement.entity.Attendance;
import com.cms.employeemanagement.entity.AttendanceStatus;
import com.cms.employeemanagement.entity.Employee;
import com.cms.employeemanagement.repository.AttendanceRepository;
import com.cms.employeemanagement.repository.EmployeeRepository;
import com.cms.employeemanagement.service.AttendanceService;

@Service
public class AttendanceServiceImpl implements AttendanceService {

    private static final Logger logger =
            LoggerFactory.getLogger(AttendanceServiceImpl.class);

    @Autowired
    private AttendanceRepository attendanceRepository;

    @Autowired
    private EmployeeRepository employeeRepository;


    // =========================================================
    // Employee Check In
    // =========================================================

    @Override
    public AttendanceDto checkIn(String employeeEmail) {

        logger.info(
                "Check-in attempt for employee: {}",
                employeeEmail
        );

        Employee employee =
                employeeRepository
                        .findByEmail(employeeEmail)
                        .orElseThrow(() -> {

                            logger.warn(
                                    "Check-in failed - employee not found: {}",
                                    employeeEmail
                            );

                            return new RuntimeException(
                                    "Employee not found"
                            );
                        });


        LocalDate today = LocalDate.now();


        Optional<Attendance> existingAttendance =
                attendanceRepository
                        .findByEmployeeEmailAndDate(
                                employeeEmail,
                                today
                        );


        if (existingAttendance.isPresent()) {

            logger.warn(
                    "Duplicate check-in attempt for employee: {}",
                    employeeEmail
            );

            throw new RuntimeException(
                    "You have already checked in today."
            );
        }


        Attendance attendance =
                new Attendance();


        attendance.setEmployeeId(
                employee.getId()
        );

        attendance.setEmployeeName(
                employee.getName()
        );

        attendance.setEmployeeEmail(
                employee.getEmail()
        );

        attendance.setDate(
                today
        );

        attendance.setCheckInTime(
                LocalDateTime.now()
        );

        attendance.setStatus(
                AttendanceStatus.PRESENT
        );


        Attendance savedAttendance =
                attendanceRepository.save(
                        attendance
                );


        logger.info(
                "Employee checked in successfully: {} ({})",
                employee.getName(),
                employeeEmail
        );


        return convertToDto(
                savedAttendance
        );
    }


    // =========================================================
    // Employee Check Out
    // =========================================================

    @Override
    public AttendanceDto checkOut(String employeeEmail) {

        logger.info(
                "Check-out attempt for employee: {}",
                employeeEmail
        );


        LocalDate today =
                LocalDate.now();


        // Find today's attendance
        Attendance attendance =
                attendanceRepository
                        .findByEmployeeEmailAndDate(
                                employeeEmail,
                                today
                        )
                        .orElseThrow(() -> {

                            logger.warn(
                                    "Check-out failed - employee has not checked in: {}",
                                    employeeEmail
                            );

                            return new RuntimeException(
                                    "Please check in first."
                            );
                        });


        // Check if already checked out
        if (attendance.getCheckOutTime() != null) {

            logger.warn(
                    "Duplicate check-out attempt for employee: {}",
                    employeeEmail
            );

            throw new RuntimeException(
                    "You have already checked out today."
            );
        }


        LocalDateTime checkOutTime =
                LocalDateTime.now();


        attendance.setCheckOutTime(
                checkOutTime
        );


        Duration duration =
                Duration.between(
                        attendance.getCheckInTime(),
                        checkOutTime
                );


        attendance.setWorkingHours(
                duration.toMinutes()
        );


        Attendance updatedAttendance =
                attendanceRepository.save(
                        attendance
                );


        logger.info(
                "Employee checked out successfully: {}. Working minutes: {}",
                employeeEmail,
                duration.toMinutes()
        );


        return convertToDto(
                updatedAttendance
        );
    }


    // =========================================================
    // OLD QR ATTENDANCE PUNCH
    // =========================================================

    @Override
    public AttendanceDto qrPunch(
            QrAttendanceRequest request) {

        // =====================================================
        // 1. REQUEST VALIDATION
        // =====================================================

        if (request == null) {

            throw new RuntimeException(
                    "QR attendance request cannot be null."
            );
        }


        // =====================================================
        // 2. QR TYPE VALIDATION
        // =====================================================

        if (!"EMS_ATTENDANCE".equals(
                request.getType())) {

            throw new RuntimeException(
                    "Invalid attendance QR code."
            );
        }


        // =====================================================
        // 3. EMAIL VALIDATION
        // =====================================================

        if (request.getEmail() == null ||
                request.getEmail().trim().isEmpty()) {

            throw new RuntimeException(
                    "Employee email is missing from QR code."
            );
        }


        /*
         * final is important here.
         *
         * We use email inside the lambda below.
         * Keeping it final makes it compatible with Java 8.
         */

        final String email =
                request.getEmail().trim();


        // =====================================================
        // 4. ACTION VALIDATION
        // =====================================================

        if (request.getAction() == null) {

            throw new RuntimeException(
                    "Attendance action is missing."
            );
        }


        final String action =
                request.getAction()
                        .trim()
                        .toUpperCase();


        if (!"CHECK_IN".equals(action)
                && !"CHECK_OUT".equals(action)) {

            throw new RuntimeException(
                    "Invalid attendance action."
            );
        }


        // =====================================================
        // 5. TIMESTAMP VALIDATION
        // =====================================================

        if (request.getIssuedAt() == null) {

            throw new RuntimeException(
                    "QR issued time is missing."
            );
        }


        if (request.getExpiresAt() == null) {

            throw new RuntimeException(
                    "QR expiry time is missing."
            );
        }


        final long currentTime =
                System.currentTimeMillis();


        final long issuedAt =
                request.getIssuedAt();


        final long expiresAt =
                request.getExpiresAt();


        // =====================================================
        // 6. CHECK FUTURE ISSUE TIME
        // =====================================================

        if (issuedAt > currentTime) {

            throw new RuntimeException(
                    "Invalid QR code issue time."
            );
        }


        // =====================================================
        // 7. CHECK QR EXPIRATION
        // =====================================================

        if (currentTime > expiresAt) {

            throw new RuntimeException(
                    "This attendance QR code has expired."
            );
        }


        // =====================================================
        // 8. FIND EMPLOYEE
        // =====================================================

        Employee employee =
                employeeRepository
                        .findByEmail(email)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Employee not found with email: "
                                                + email
                                )
                        );


        // =====================================================
        // 9. PERFORM CHECK-IN
        // =====================================================

        if ("CHECK_IN".equals(action)) {

            logger.info(
                    "QR CHECK_IN request received for employee: {}",
                    email
            );

            return checkIn(
                    employee.getEmail()
            );
        }


        // =====================================================
        // 10. PERFORM CHECK-OUT
        // =====================================================

        if ("CHECK_OUT".equals(action)) {

            logger.info(
                    "QR CHECK_OUT request received for employee: {}",
                    email
            );

            return checkOut(
                    employee.getEmail()
            );
        }


        // =====================================================
        // 11. FALLBACK
        // =====================================================

        throw new RuntimeException(
                "Unable to process attendance."
        );
    }


    // =========================================================
    // NEW PERMANENT EMPLOYEE QR SCAN
    // =========================================================

    @Override
    public AttendanceDto scanEmployeeQr(String qrToken) {

        logger.info(
                "Permanent employee QR scan attempt."
        );


        // =====================================================
        // 1. VALIDATE QR TOKEN
        // =====================================================

        if (qrToken == null ||
                qrToken.trim().isEmpty()) {

            throw new RuntimeException(
                    "QR token is missing."
            );
        }


        final String token =
                qrToken.trim();


        // =====================================================
        // 2. FIND EMPLOYEE USING QR TOKEN
        // =====================================================

        Employee employee =
                employeeRepository
                        .findByQrToken(token)
                        .orElseThrow(() -> {

                            logger.warn(
                                    "QR scan failed - employee not found for QR token."
                            );

                            return new RuntimeException(
                                    "Invalid employee QR code."
                            );
                        });


        final String employeeEmail =
                employee.getEmail();


        logger.info(
                "Employee identified through QR: {} ({})",
                employee.getName(),
                employeeEmail
        );


        // =====================================================
        // 3. CHECK TODAY'S ATTENDANCE
        // =====================================================

        LocalDate today =
                LocalDate.now();


        Optional<Attendance> existingAttendance =
                attendanceRepository
                        .findByEmployeeEmailAndDate(
                                employeeEmail,
                                today
                        );


        // =====================================================
        // 4. NO ATTENDANCE TODAY -> CHECK IN
        // =====================================================

        if (!existingAttendance.isPresent()) {

            logger.info(
                    "No attendance found for {}. Automatically checking in.",
                    employeeEmail
            );

            return checkIn(
                    employeeEmail
            );
        }


        // =====================================================
        // 5. CHECK-IN EXISTS BUT NO CHECK-OUT -> CHECK OUT
        // =====================================================

        Attendance attendance =
                existingAttendance.get();


        if (attendance.getCheckOutTime() == null) {

            logger.info(
                    "Employee {} is checked in. Automatically checking out.",
                    employeeEmail
            );

            return checkOut(
                    employeeEmail
            );
        }


        // =====================================================
        // 6. BOTH CHECK-IN AND CHECK-OUT ALREADY EXIST
        // =====================================================

        logger.warn(
                "Employee {} has already completed attendance for today.",
                employeeEmail
        );


        throw new RuntimeException(
                "Attendance already completed for today."
        );
    }


    // =========================================================
    // Get Today's Attendance
    // =========================================================

    @Override
    public AttendanceDto getTodayAttendance(
            String employeeEmail) {

        logger.info(
                "Fetching today's attendance for employee: {}",
                employeeEmail
        );


        LocalDate today =
                LocalDate.now();


        Optional<Attendance> optionalAttendance =
                attendanceRepository
                        .findByEmployeeEmailAndDate(
                                employeeEmail,
                                today
                        );


        if (!optionalAttendance.isPresent()) {

            logger.info(
                    "No attendance record found for today: {}",
                    employeeEmail
            );

            return null;
        }


        Attendance attendance =
                optionalAttendance.get();


        logger.info(
                "Today's attendance found for {} with status: {}",
                employeeEmail,
                attendance.getStatus()
        );


        return convertToDto(
                attendance
        );
    }


    // =========================================================
    // Get Attendance History
    // =========================================================

    @Override
    public List<AttendanceDto> getAttendanceHistory(
            String employeeEmail) {

        logger.info(
                "Fetching attendance history for employee: {}",
                employeeEmail
        );


        List<Attendance> attendanceList =
                attendanceRepository
                        .findByEmployeeEmailOrderByDateDesc(
                                employeeEmail
                        );


        logger.info(
                "Attendance history records found for {}: {}",
                employeeEmail,
                attendanceList.size()
        );


        return attendanceList
                .stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }


    // =========================================================
    // Get All Attendance
    // =========================================================

    @Override
    public List<AttendanceDto> getAllAttendance() {

        logger.info(
                "Fetching all attendance records"
        );


        List<Attendance> attendanceList =
                attendanceRepository
                        .findAllByOrderByDateDesc();


        logger.info(
                "Total attendance records found: {}",
                attendanceList.size()
        );


        return attendanceList
                .stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }


    // =========================================================
    // Get Attendance By Date
    // =========================================================

    @Override
    public AttendanceDto getAttendanceByDate(
            String employeeEmail,
            String date) {

        logger.info(
                "Fetching attendance for employee: {} on date: {}",
                employeeEmail,
                date
        );


        LocalDate attendanceDate;


        try {

            attendanceDate =
                    LocalDate.parse(date);

        } catch (Exception e) {

            logger.warn(
                    "Invalid attendance date: {}",
                    date
            );

            throw new RuntimeException(
                    "Invalid date format. Use yyyy-MM-dd."
            );
        }


        Optional<Attendance> optionalAttendance =
                attendanceRepository
                        .findByEmployeeEmailAndDate(
                                employeeEmail,
                                attendanceDate
                        );


        if (!optionalAttendance.isPresent()) {

            logger.info(
                    "No attendance found for {} on {}",
                    employeeEmail,
                    date
            );


            AttendanceDto dto =
                    new AttendanceDto();


            dto.setId(null);


            Optional<Employee> optionalEmployee =
                    employeeRepository
                            .findByEmail(
                                    employeeEmail
                            );


            if (optionalEmployee.isPresent()) {

                Employee employee =
                        optionalEmployee.get();


                dto.setEmployeeId(
                        employee.getId()
                );

                dto.setEmployeeName(
                        employee.getName()
                );

                dto.setEmployeeEmail(
                        employee.getEmail()
                );

            } else {

                dto.setEmployeeEmail(
                        employeeEmail
                );
            }


            dto.setDate(
                    attendanceDate
            );


            dto.setCheckInTime(
                    null
            );


            dto.setCheckOutTime(
                    null
            );


            dto.setWorkingHours(
                    "-"
            );


            dto.setStatus(
                    AttendanceStatus.ABSENT
            );


            return dto;
        }


        Attendance attendance =
                optionalAttendance.get();


        return convertToDto(
                attendance
        );
    }


    // =========================================================
    // Get Attendance For All Employees By Date
    // =========================================================

    @Override
    public List<AttendanceDto> getAttendanceForAllEmployeesByDate(
            String date) {

        logger.info(
                "Fetching attendance for all employees on date: {}",
                date
        );


        LocalDate attendanceDate;


        try {

            attendanceDate =
                    LocalDate.parse(date);

        } catch (Exception e) {

            logger.warn(
                    "Invalid attendance date: {}",
                    date
            );

            throw new RuntimeException(
                    "Invalid date format. Use yyyy-MM-dd."
            );
        }


        List<Employee> employees =
                employeeRepository.findAll();


        logger.info(
                "Total employees found: {}",
                employees.size()
        );


        List<Attendance> attendanceList =
                attendanceRepository.findByDate(
                        attendanceDate
                );


        logger.info(
                "Existing attendance records for {}: {}",
                date,
                attendanceList.size()
        );


        List<AttendanceDto> result =
                employees
                        .stream()
                        .map(employee -> {

                            Optional<Attendance>
                                    attendanceOptional =
                                    attendanceList
                                            .stream()
                                            .filter(attendance ->
                                                    attendance
                                                            .getEmployeeEmail()
                                                            .equalsIgnoreCase(
                                                                    employee.getEmail()
                                                            )
                                            )
                                            .findFirst();


                            if (attendanceOptional.isPresent()) {

                                Attendance attendance =
                                        attendanceOptional.get();


                                logger.debug(
                                        "Attendance found for {}: {}",
                                        employee.getEmail(),
                                        attendance.getStatus()
                                );


                                return convertToDto(
                                        attendance
                                );
                            }


                            logger.debug(
                                    "No attendance found for {}. Displaying ABSENT.",
                                    employee.getEmail()
                            );


                            AttendanceDto dto =
                                    new AttendanceDto();


                            dto.setId(null);


                            dto.setEmployeeId(
                                    employee.getId()
                            );


                            dto.setEmployeeName(
                                    employee.getName()
                            );


                            dto.setEmployeeEmail(
                                    employee.getEmail()
                            );


                            dto.setDate(
                                    attendanceDate
                            );


                            dto.setCheckInTime(
                                    null
                            );


                            dto.setCheckOutTime(
                                    null
                            );


                            dto.setWorkingHours(
                                    "-"
                            );


                            dto.setStatus(
                                    AttendanceStatus.ABSENT
                            );


                            return dto;

                        })
                        .collect(Collectors.toList());


        logger.info(
                "Attendance management result generated for {}. Total employees: {}",
                date,
                result.size()
        );


        return result;
    }


    // =========================================================
    // Convert Entity To DTO
    // =========================================================

    private AttendanceDto convertToDto(
            Attendance attendance) {

        AttendanceDto dto =
                new AttendanceDto();


        dto.setId(
                attendance.getId()
        );


        dto.setEmployeeId(
                attendance.getEmployeeId()
        );


        dto.setEmployeeName(
                attendance.getEmployeeName()
        );


        dto.setEmployeeEmail(
                attendance.getEmployeeEmail()
        );


        dto.setDate(
                attendance.getDate()
        );


        dto.setCheckInTime(
                attendance.getCheckInTime()
        );


        dto.setCheckOutTime(
                attendance.getCheckOutTime()
        );


        dto.setWorkingHours(
                attendance.getFormattedWorkingHours()
        );


        dto.setStatus(
                attendance.getStatus()
        );


        return dto;
    }
}