package com.cms.employeemanagement.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.http.HttpMethod;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.cms.employeemanagement.security.CustomUserDetailsService;
import com.cms.employeemanagement.security.JwtAuthenticationFilter;

@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;


    
    @Bean
    public PasswordEncoder passwordEncoder() {

        return new BCryptPasswordEncoder();
    }


   
    @Bean
    public AuthenticationManager authenticationManager(
            HttpSecurity http) throws Exception {

        AuthenticationManagerBuilder builder =
                http.getSharedObject(
                        AuthenticationManagerBuilder.class
                );

        builder
                .userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder());

        return builder.build();
    }


   
    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http) throws Exception {

        http

            
            .cors()

            .and()

           
            .csrf()
            .disable()

          
            .headers()
            .frameOptions()
            .disable()

            .and()

         
            .sessionManagement()
            .sessionCreationPolicy(
                    SessionCreationPolicy.STATELESS
            )

            .and()

            
            .authorizeRequests()


           

            .antMatchers(
                    "/api/users/login",
                    "/api/users/verify-otp",
                    "/api/users/forgot-password"
            )
            .permitAll()




            .antMatchers(
                    "/h2-console/**"
            )
            .permitAll()



            .antMatchers(
                    "/swagger-ui/**",
                    "/swagger-resources/**",
                    "/v2/api-docs",
                    "/webjars/**"
            )
            .permitAll()


            
            .antMatchers(
                    HttpMethod.DELETE,
                    "/api/employees/**"
            )
            .hasRole("ADMIN")


          
            .antMatchers(
                    HttpMethod.POST,
                    "/api/employees/upload"
            )
            .hasRole("ADMIN")


          
            .antMatchers(
                    "/api/employees/**"
            )
            .hasAnyRole(
                    "ADMIN",
                    "HR"
            )


        
            .anyRequest()
            .authenticated()



            .and()

            .addFilterBefore(
                    jwtAuthenticationFilter,
                    UsernamePasswordAuthenticationFilter.class
            );


        return http.build();
    }
}
