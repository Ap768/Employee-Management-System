package com.cms.employeemanagement.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.cms.employeemanagement.entity.Role;
import com.cms.employeemanagement.entity.User;
import com.cms.employeemanagement.repository.UserRepository;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {

        // ==========================================
        // ADMIN USER
        // ==========================================

        if (!userRepository.existsByEmail("admin@gmail.com")) {

            User admin = new User();

            admin.setEmail("admin@gmail.com");

            admin.setPassword(
                    passwordEncoder.encode("admin123")
            );

            admin.setRole(Role.ROLE_ADMIN);

            userRepository.save(admin);

            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "ADMIN USER CREATED"
            );

            System.out.println(
                    "Email    : admin@gmail.com"
            );

            System.out.println(
                    "Password : admin123"
            );

            System.out.println(
                    "Role     : ROLE_ADMIN"
            );

            System.out.println(
                    "========================================"
            );
        }


        // ==========================================
        // HR USER
        // ==========================================

        if (!userRepository.existsByEmail("hr@gmail.com")) {

            User hr = new User();

            hr.setEmail("hr@gmail.com");

            hr.setPassword(
                    passwordEncoder.encode("hr123")
            );

            hr.setRole(Role.ROLE_HR);

            userRepository.save(hr);

            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "HR USER CREATED"
            );

            System.out.println(
                    "Email    : hr@gmail.com"
            );

            System.out.println(
                    "Password : hr123"
            );

            System.out.println(
                    "Role     : ROLE_HR"
            );

            System.out.println(
                    "========================================"
            );
        }
    }
}