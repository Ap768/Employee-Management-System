package com.cms.employeemanagement.service.impl;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.employeemanagement.dto.ForgotPasswordRequest;
import com.cms.employeemanagement.dto.LoginRequest;
import com.cms.employeemanagement.dto.LoginResponse;
import com.cms.employeemanagement.dto.OtpRequest;

import com.cms.employeemanagement.entity.Otp;
import com.cms.employeemanagement.entity.User;

import com.cms.employeemanagement.repository.OtpRepository;
import com.cms.employeemanagement.repository.UserRepository;

import com.cms.employeemanagement.security.JwtUtil;

import com.cms.employeemanagement.service.OtpService;
import com.cms.employeemanagement.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OtpRepository otpRepository;

    @Autowired
    private OtpService otpService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;



    @Override
    @Transactional
    public String login(LoginRequest request) {

        
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );


        
        Optional<User> optionalUser =
                userRepository.findByEmail(
                        request.getEmail()
                );


        if (!optionalUser.isPresent()) {

            throw new RuntimeException(
                    "User not found"
            );
        }


        User user = optionalUser.get();


        
        String otpValue =
                otpService.generateOtp();


        
        Otp otp = new Otp();

        otp.setEmail(user.getEmail());

        otp.setOtp(otpValue);

        otp.setExpiryTime(
                LocalDateTime.now().plusMinutes(5)
        );


       
        otpRepository.deleteByEmail(
                user.getEmail()
        );


        otpRepository.save(otp);


        
        System.out.println(
                "========================================"
        );

        System.out.println(
                "LOGIN OTP"
        );

        System.out.println(
                "Email : " + user.getEmail()
        );

        System.out.println(
                "OTP   : " + otpValue
        );

        System.out.println(
                "========================================"
        );


        return "OTP_SENT";
    }



    @Override
    public LoginResponse verifyOtp(
            OtpRequest request) {


        boolean valid =
                otpService.validateOtp(
                        request.getEmail(),
                        request.getOtp()
                );


        if (!valid) {

            throw new RuntimeException(
                    "Invalid or expired OTP"
            );
        }


       
        User user =
                userRepository
                        .findByEmail(
                                request.getEmail()
                        )
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "User not found"
                                )
                        );


      
        String token =
                jwtUtil.generateToken(
                        user.getEmail(),
                        user.getRole().name()
                );


        otpRepository.deleteByEmail(
                user.getEmail()
        );


       
        return new LoginResponse(
                user.getEmail(),
                user.getRole().name(),
                token
        );
    }



    @Override
    @Transactional
    public String forgotPassword(
            ForgotPasswordRequest request) {


        
        Optional<User> optionalUser =
                userRepository.findByEmail(
                        request.getEmail()
                );


        if (!optionalUser.isPresent()) {

            throw new RuntimeException(
                    "Email not found"
            );
        }



        String otpValue =
                otpService.generateOtp();


        Otp otp = new Otp();

        otp.setEmail(
                request.getEmail()
        );

        otp.setOtp(
                otpValue
        );

        otp.setExpiryTime(
                LocalDateTime.now().plusMinutes(5)
        );


               otpRepository.deleteByEmail(
                request.getEmail()
        );


       
        otpRepository.save(otp);


        
        System.out.println(
                "========================================"
        );

        System.out.println(
                "FORGOT PASSWORD OTP"
        );

        System.out.println(
                "Email : " + request.getEmail()
        );

        System.out.println(
                "OTP   : " + otpValue
        );

        System.out.println(
                "========================================"
        );


        return "OTP_SENT";
    }
}