package com.cms.employeemanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.cms.employeemanagement.dto.LeaveBalanceDto;
import com.cms.employeemanagement.dto.LeaveRequestDto;
import com.cms.employeemanagement.entity.LeaveRequest;
import com.cms.employeemanagement.service.LeaveService;

@RestController
@RequestMapping("/api/leaves")
@CrossOrigin(origins = "*")
public class LeaveController {

    @Autowired
    private LeaveService leaveService;


    @PreAuthorize("hasRole('EMPLOYEE')")
    @PostMapping("/apply")
    public ResponseEntity<LeaveRequest> applyLeave(
            @RequestBody LeaveRequestDto request,
            Authentication authentication) {

        String loggedInEmail = authentication.getName();

        // Employee can apply leave only for himself
        if (!loggedInEmail.equalsIgnoreCase(request.getEmployeeEmail())) {
            return ResponseEntity.status(403).build();
        }

        return ResponseEntity.ok(
                leaveService.applyLeave(request)
        );
    }



    @PreAuthorize("hasAnyRole('EMPLOYEE', 'HR', 'ADMIN')")
    @GetMapping("/my/{email}")
    public ResponseEntity<List<LeaveRequest>> getMyLeaves(
            @PathVariable String email,
            Authentication authentication) {

        String loggedInEmail = authentication.getName();

        boolean isAdmin = authentication.getAuthorities()
                .stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        boolean isHr = authentication.getAuthorities()
                .stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_HR"));

        // Employee can see only his own leaves
        if (!isAdmin && !isHr &&
                !loggedInEmail.equalsIgnoreCase(email)) {

            return ResponseEntity.status(403).build();
        }

        return ResponseEntity.ok(
                leaveService.getMyLeaves(email)
        );
    }


    @PreAuthorize("hasAnyRole('EMPLOYEE', 'HR', 'ADMIN')")
    @GetMapping("/balance/{email}")
    public ResponseEntity<LeaveBalanceDto> getLeaveBalance(
            @PathVariable String email,
            Authentication authentication) {

        String loggedInEmail = authentication.getName();

        boolean isAdmin = authentication.getAuthorities()
                .stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        boolean isHr = authentication.getAuthorities()
                .stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_HR"));

        if (!isAdmin && !isHr &&
                !loggedInEmail.equalsIgnoreCase(email)) {

            return ResponseEntity.status(403).build();
        }

        return ResponseEntity.ok(
                leaveService.getLeaveBalance(email)
        );
    }


    @PreAuthorize("hasAnyRole('ADMIN', 'HR')")
    @GetMapping
    public ResponseEntity<List<LeaveRequest>> getAllLeaves() {

        return ResponseEntity.ok(
                leaveService.getAllLeaves()
        );
    }



    @PreAuthorize("hasAnyRole('ADMIN', 'HR')")
    @PutMapping("/{id}/approve")
    public ResponseEntity<LeaveRequest> approveLeave(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                leaveService.approveLeave(id)
        );
    }


    @PreAuthorize("hasAnyRole('ADMIN', 'HR')")
    @PutMapping("/{id}/reject")
    public ResponseEntity<LeaveRequest> rejectLeave(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                leaveService.rejectLeave(id)
        );
    }


    @PreAuthorize("hasRole('EMPLOYEE')")
    @PutMapping("/{id}/cancel")
    public ResponseEntity<LeaveRequest> cancelLeave(
            @PathVariable Long id,
            Authentication authentication) {

        String loggedInEmail = authentication.getName();

        LeaveRequest leave = leaveService.getLeaveById(id);

        // Employee can cancel only his own leave
        if (!loggedInEmail.equalsIgnoreCase(
                leave.getEmployeeEmail())) {

            return ResponseEntity.status(403).build();
        }

        return ResponseEntity.ok(
                leaveService.cancelLeave(id)
        );
    }
}