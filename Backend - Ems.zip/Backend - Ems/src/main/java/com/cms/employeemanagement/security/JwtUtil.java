package com.cms.employeemanagement.security;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {

    private static final String SECRET_KEY =
            "CMS_EMPLOYEE_MANAGEMENT_SYSTEM_SECRET_KEY_2026";


        private static final long EXPIRATION_TIME =
            1000 * 60 * 60 * 10;


    private Key getSigningKey() {

        return Keys.hmacShaKeyFor(
                SECRET_KEY.getBytes(StandardCharsets.UTF_8)
        );
    }


       public String generateToken(
            String email,
            String role) {

        return Jwts.builder()

              
                .setSubject(email)

                              .claim("role", role)

               
                .setIssuedAt(new Date())

                                .setExpiration(
                        new Date(
                                System.currentTimeMillis()
                                + EXPIRATION_TIME
                        )
                )

                                .signWith(
                        getSigningKey(),
                        SignatureAlgorithm.HS256
                )

                .compact();
    }


        public String extractEmail(String token) {

        return getClaims(token).getSubject();
    }


        public String extractRole(String token) {

        return getClaims(token)
                .get("role", String.class);
    }


        public boolean isTokenValid(String token) {

        try {

            Claims claims = getClaims(token);

            return claims
                    .getExpiration()
                    .after(new Date());

        } catch (Exception e) {

            return false;
        }
    }

    private Claims getClaims(String token) {

        return Jwts.parserBuilder()

                .setSigningKey(getSigningKey())

                .build()

                .parseClaimsJws(token)

                .getBody();
    }
}