package com.cms.employeemanagement.service.impl;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.employeemanagement.dto.LeaveBalanceDto;
import com.cms.employeemanagement.dto.LeaveRequestDto;
import com.cms.employeemanagement.entity.Employee;
import com.cms.employeemanagement.entity.LeaveRequest;
import com.cms.employeemanagement.entity.LeaveStatus;
import com.cms.employeemanagement.entity.LeaveType;
import com.cms.employeemanagement.repository.EmployeeRepository;
import com.cms.employeemanagement.repository.LeaveRepository;
import com.cms.employeemanagement.service.LeaveService;

@Service
@Transactional
public class LeaveServiceImpl implements LeaveService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private LeaveRepository leaveRepository;

    // =========================================================
    // APPLY LEAVE
    // =========================================================

    @Override
    public LeaveRequest applyLeave(LeaveRequestDto request) {

        if (request.getEmployeeEmail() == null
                || request.getEmployeeEmail().trim().isEmpty()) {

            throw new RuntimeException("Employee Email is missing.");
        }

        if (request.getLeaveType() == null) {
            throw new RuntimeException("Leave Type is required.");
        }

        if (request.getFromDate() == null) {
            throw new RuntimeException("From Date is required.");
        }

        if (request.getToDate() == null) {
            throw new RuntimeException("To Date is required.");
        }

        if (request.getToDate().isBefore(request.getFromDate())) {
            throw new RuntimeException(
                    "To Date cannot be before From Date."
            );
        }

        Employee employee = employeeRepository
                .findByEmail(request.getEmployeeEmail())
                .orElseThrow(() -> new RuntimeException(
                        "Employee not found with email: "
                                + request.getEmployeeEmail()
                ));

        LeaveRequest leave = new LeaveRequest();

        leave.setEmployeeId(employee.getId());
        leave.setEmployeeName(employee.getName());
        leave.setEmployeeEmail(employee.getEmail());

        leave.setLeaveType(request.getLeaveType());

        leave.setFromDate(request.getFromDate());
        leave.setToDate(request.getToDate());

        leave.setReason(request.getReason());

        leave.setStatus(LeaveStatus.PENDING);

        leave.setAppliedDate(LocalDateTime.now());

        return leaveRepository.save(leave);
    }

    // =========================================================
    // GET MY LEAVES
    // =========================================================

    @Override
    public List<LeaveRequest> getMyLeaves(String email) {

        if (email == null || email.trim().isEmpty()) {
            throw new RuntimeException("Employee Email is required.");
        }

        return leaveRepository.findByEmployeeEmail(email);
    }

    // =========================================================
    // GET LEAVE BALANCE
    // =========================================================

    @Override
    public LeaveBalanceDto getLeaveBalance(String email) {

        if (email == null || email.trim().isEmpty()) {
            throw new RuntimeException("Employee Email is required.");
        }

        Employee employee = employeeRepository
                .findByEmail(email)
                .orElseThrow(() -> new RuntimeException(
                        "Employee not found with email: " + email
                ));

        return new LeaveBalanceDto(
                employee.getCasualLeave(),
                employee.getSickLeave(),
                employee.getEarnedLeave()
        );
    }

    // =========================================================
    // GET ALL LEAVES
    // ADMIN + HR
    // =========================================================

    @Override
    public List<LeaveRequest> getAllLeaves() {

        return leaveRepository.findAll();
    }

    // =========================================================
    // GET LEAVE BY ID
    // USED FOR OWNERSHIP CHECK
    // =========================================================

    @Override
    public LeaveRequest getLeaveById(Long id) {

        if (id == null) {
            throw new RuntimeException("Leave ID is required.");
        }

        return leaveRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "Leave Request Not Found"
                ));
    }

    // =========================================================
    // APPROVE LEAVE
    // ADMIN + HR
    // =========================================================

    @Override
    public LeaveRequest approveLeave(Long id) {

        LeaveRequest leave = leaveRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "Leave Request Not Found"
                ));

        // Only PENDING leave can be approved
        if (leave.getStatus() != LeaveStatus.PENDING) {

            throw new RuntimeException(
                    "Only Pending Leave Can Be Approved"
            );
        }

        Employee employee = employeeRepository
                .findByEmail(leave.getEmployeeEmail())
                .orElseThrow(() -> new RuntimeException(
                        "Employee Not Found"
                ));

        // Calculate number of leave days
        long days = ChronoUnit.DAYS.between(
                leave.getFromDate(),
                leave.getToDate()
        ) + 1;

        LeaveType leaveType = leave.getLeaveType();

        if (leaveType == null) {

            throw new RuntimeException(
                    "Leave Type is required."
            );
        }

        switch (leaveType) {

            // =================================================
            // CASUAL LEAVE
            // =================================================

            case CASUAL:

                if (employee.getCasualLeave() < days) {

                    throw new RuntimeException(
                            "Insufficient Casual Leave Balance"
                    );
                }

                employee.setCasualLeave(
                        employee.getCasualLeave()
                                - (int) days
                );

                break;

            // =================================================
            // SICK LEAVE
            // =================================================

            case SICK:

                if (employee.getSickLeave() < days) {

                    throw new RuntimeException(
                            "Insufficient Sick Leave Balance"
                    );
                }

                employee.setSickLeave(
                        employee.getSickLeave()
                                - (int) days
                );

                break;

            // =================================================
            // EARNED LEAVE
            // =================================================

            case EARNED:

                if (employee.getEarnedLeave() < days) {

                    throw new RuntimeException(
                            "Insufficient Earned Leave Balance"
                    );
                }

                employee.setEarnedLeave(
                        employee.getEarnedLeave()
                                - (int) days
                );

                break;

            // =================================================
            // UNPAID LEAVE
            // =================================================

            case UNPAID:

                // No leave balance deduction
                break;

            // =================================================
            // INVALID
            // =================================================

            default:

                throw new RuntimeException(
                        "Invalid Leave Type"
                );
        }

        // Save updated employee leave balance
        employeeRepository.save(employee);

        // Update leave status
        leave.setStatus(LeaveStatus.APPROVED);

        return leaveRepository.save(leave);
    }

    // =========================================================
    // REJECT LEAVE
    // ADMIN + HR
    // =========================================================

    @Override
    public LeaveRequest rejectLeave(Long id) {

        LeaveRequest leave = leaveRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "Leave Request Not Found"
                ));

        // Only pending leave can be rejected
        if (leave.getStatus() != LeaveStatus.PENDING) {

            throw new RuntimeException(
                    "Only Pending Leave Can Be Rejected"
            );
        }

        leave.setStatus(LeaveStatus.REJECTED);

        return leaveRepository.save(leave);
    }

    // =========================================================
    // CANCEL LEAVE
    // EMPLOYEE
    // =========================================================

    @Override
    public LeaveRequest cancelLeave(Long id) {

        LeaveRequest leave = leaveRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "Leave Request Not Found"
                ));

        // Only pending leave can be cancelled
        if (leave.getStatus() != LeaveStatus.PENDING) {

            throw new RuntimeException(
                    "Only Pending Leave Can Be Cancelled"
            );
        }

        leave.setStatus(LeaveStatus.CANCELLED);

        return leaveRepository.save(leave);
    }
}