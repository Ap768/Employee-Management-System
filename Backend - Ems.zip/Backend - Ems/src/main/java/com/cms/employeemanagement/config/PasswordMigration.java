package com.cms.employeemanagement.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.cms.employeemanagement.entity.Role;
import com.cms.employeemanagement.entity.User;
import com.cms.employeemanagement.repository.UserRepository;

@Component
public class PasswordMigration implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {

        List<User> users = userRepository.findAll();

        for (User user : users) {

            String password = user.getPassword();

            if (password != null &&
                    (password.startsWith("$2a$")
                    || password.startsWith("$2b$")
                    || password.startsWith("$2y$"))) {

                continue;
            }

            if (user.getRole() == Role.ROLE_ADMIN) {

                user.setPassword(
                    passwordEncoder.encode("admin123")
                );

            } else if (user.getRole() == Role.ROLE_HR) {

                user.setPassword(
                    passwordEncoder.encode("hr123")
                );

            } else if (user.getRole() == Role.ROLE_EMPLOYEE) {

                user.setPassword(
                    passwordEncoder.encode("employee123")
                );
            }

            userRepository.save(user);
        }

        System.out.println("========================================");
        System.out.println("PASSWORD MIGRATION COMPLETED");
        System.out.println("========================================");
    }
}