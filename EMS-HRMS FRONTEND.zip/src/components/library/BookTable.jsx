import { BookPlus, Pencil, QrCode, Trash2 } from "lucide-react";

function BookTable({ books, loading, canDelete, onAddBook, onEditBook, onDeleteBook, onViewQr }) {
    return (
        <section className="library-section" aria-labelledby="library-books-title">
            <header className="library-section-header">
                <div>
                    <h2 id="library-books-title">Books</h2>
                    <p>Browse and manage the library catalogue.</p>
                </div>
                <button className="library-primary-button" type="button" onClick={onAddBook}>
                    <BookPlus size={17} aria-hidden="true" />
                    Add book
                </button>
            </header>

            <div className="library-table-wrap">
                <table className="library-table">
                    <thead>
                        <tr>
                            <th scope="col">Book ID</th>
                            <th scope="col">Title</th>
                            <th scope="col">Author</th>
                            <th scope="col">ISBN</th>
                            <th scope="col">Barcode</th>
                            <th scope="col">Category</th>
                            <th scope="col">Status</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan="8" className="library-table-message">Loading books...</td></tr>
                        ) : books.length === 0 ? (
                            <tr><td colSpan="8" className="library-table-message">No books found.</td></tr>
                        ) : books.map((book) => {
                            const status = String(book.status || "UNKNOWN").toUpperCase();
                            return (
                                <tr key={book.id ?? book.bookId ?? book.barcode}>
                                    <td>{book.id ?? book.bookId ?? "-"}</td>
                                    <td className="library-book-title-cell">{book.title || "-"}</td>
                                    <td>{book.author || "-"}</td>
                                    <td>{book.isbn || "-"}</td>
                                    <td><span className="library-code">{book.barcode || "-"}</span></td>
                                    <td>{book.category || "-"}</td>
                                    <td><span className={`library-status-badge ${status === "AVAILABLE" ? "is-available" : status === "ISSUED" ? "is-issued" : ""}`}>{status}</span></td>
                                    <td>
                                        <div className="library-row-actions">
                                            <button className="library-icon-button" type="button" onClick={() => onEditBook(book)} aria-label={`Edit ${book.title || "book"}`} title="Edit book">
                                                <Pencil size={16} aria-hidden="true" />
                                            </button>
                                            <button className="library-icon-button" type="button" onClick={() => onViewQr(book)} aria-label={`View QR code for ${book.title || "book"}`} title="View QR code">
                                                <QrCode size={16} aria-hidden="true" />
                                            </button>
                                            {canDelete && (
                                                <button className="library-icon-button is-danger" type="button" onClick={() => onDeleteBook(book)} aria-label={`Delete ${book.title || "book"}`} title="Delete book">
                                                    <Trash2 size={16} aria-hidden="true" />
                                                </button>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </section>
    );
}

export default BookTable;
