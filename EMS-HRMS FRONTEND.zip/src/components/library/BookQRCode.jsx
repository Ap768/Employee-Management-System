import { QRCodeCanvas } from "qrcode.react";

function BookQRCode({ barcode }) {
    const value = String(barcode || "").trim();

    if (!value) {
        return (
            <p className="library-qr-error" role="alert">
                Cannot generate QR code because this book does not have a barcode.
            </p>
        );
    }

    return (
        <div className="library-qr-code">
            <QRCodeCanvas
                value={value}
                size={220}
                level="H"
                includeMargin
                aria-label={`QR code for barcode ${value}`}
            />
            <span className="library-qr-barcode">{value}</span>
        </div>
    );
}

export default BookQRCode;
