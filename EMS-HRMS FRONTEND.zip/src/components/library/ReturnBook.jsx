import { useState } from "react";
import { RotateCcw, ScanLine } from "lucide-react";
import QRScanner from "./QRScanner";

function ReturnBook({ book, submitting, onScanBook, onReturn }) {
    const [scannerOpen, setScannerOpen] = useState(false);
    const status = String(book?.status || "").toUpperCase();
    const canReturn = Boolean(book?.barcode && status === "ISSUED");

    function handleScan(value) {
        setScannerOpen(false);
        onScanBook(value);
    }

    return (
        <section className="library-section" aria-labelledby="library-return-title">
            <header className="library-section-header">
                <div>
                    <h2 id="library-return-title">Return book</h2>
                    <p>Scan an issued book to complete its return.</p>
                </div>
                <button className="library-secondary-button" type="button" onClick={() => setScannerOpen(true)}>
                    <ScanLine size={17} aria-hidden="true" />
                    Scan book barcode / QR
                </button>
            </header>

            <div className="library-selection library-return-selection" aria-live="polite">
                {book ? (
                    <>
                        <strong>{book.title || "Untitled book"}</strong>
                        <span>{book.author || "Author not listed"}</span>
                        <span>Barcode: {book.barcode || "-"}</span>
                        <span className={`library-status-badge ${status === "AVAILABLE" ? "is-available" : status === "ISSUED" ? "is-issued" : ""}`}>{status || "UNKNOWN"}</span>
                    </>
                ) : (
                    <span className="library-muted">Scan a book to see its current status</span>
                )}
            </div>

            {book && status === "AVAILABLE" && (
                <p className="library-inline-notice" role="status">Book is already available.</p>
            )}

            <footer className="library-flow-footer">
                <button className="library-primary-button" type="button" disabled={!canReturn || submitting} onClick={onReturn}>
                    <RotateCcw size={17} aria-hidden="true" />
                    {submitting ? "Returning..." : "Return book"}
                </button>
            </footer>

            {scannerOpen && (
                <QRScanner
                    onScan={handleScan}
                    onClose={() => setScannerOpen(false)}
                />
            )}
        </section>
    );
}

export default ReturnBook;
