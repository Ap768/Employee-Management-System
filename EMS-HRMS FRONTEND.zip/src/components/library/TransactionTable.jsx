function formatDate(value) {
    if (!value) return "-";
    const dateOnly = String(value).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    const date = dateOnly
        ? new Date(Number(dateOnly[1]), Number(dateOnly[2]) - 1, Number(dateOnly[3]))
        : new Date(value);
    return Number.isNaN(date.getTime())
        ? String(value)
        : date.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" });
}

function TransactionTable({ transactions, loading, filterLabel, onShowAll }) {
    return (
        <section className="library-section" aria-labelledby="library-transactions-title">
            <header className="library-section-header">
                <div>
                    <h2 id="library-transactions-title">Transaction history</h2>
                    <p>{filterLabel ? `Showing transactions for ${filterLabel}.` : "Review recent issues and returns."}</p>
                </div>
                {filterLabel && (
                    <button className="library-text-button" type="button" onClick={onShowAll}>Show all transactions</button>
                )}
            </header>

            <div className="library-table-wrap">
                <table className="library-table">
                    <thead>
                        <tr>
                            <th scope="col">Employee</th>
                            <th scope="col">Book</th>
                            <th scope="col">Barcode</th>
                            <th scope="col">Issue date</th>
                            <th scope="col">Return date</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan="6" className="library-table-message">Loading transactions...</td></tr>
                        ) : transactions.length === 0 ? (
                            <tr><td colSpan="6" className="library-table-message">No transactions found.</td></tr>
                        ) : transactions.map((transaction) => {
                            const status = String(transaction.status || "UNKNOWN").toUpperCase();
                            const employeeName = transaction.employeeName || transaction.employee?.name || transaction.employee?.fullName || "-";
                            const bookTitle = transaction.bookTitle || transaction.book?.title || "-";
                            const barcode = transaction.barcode || transaction.book?.barcode || "-";
                            return (
                                <tr key={transaction.id ?? `${barcode}-${transaction.issueDate ?? transaction.issuedAt}`}>
                                    <td>{employeeName}</td>
                                    <td className="library-book-title-cell">{bookTitle}</td>
                                    <td><span className="library-code">{barcode}</span></td>
                                    <td>{formatDate(transaction.issueDate || transaction.issuedAt)}</td>
                                    <td>{formatDate(transaction.returnDate || transaction.returnedAt)}</td>
                                    <td><span className={`library-status-badge ${status === "RETURNED" ? "is-available" : status === "ISSUED" ? "is-issued" : ""}`}>{status}</span></td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </section>
    );
}

export default TransactionTable;
