import { useState } from "react";
import { ScanLine, UserRound, BookOpenCheck, History } from "lucide-react";
import QRScanner from "./QRScanner";

function IssueBook({ employee, book, submitting, onScanEmployee, onScanBook, onIssue, onViewTransactions }) {
    const [scannerType, setScannerType] = useState("");
    const canIssue = Boolean(employee?.id && book?.barcode && String(book.status).toUpperCase() === "AVAILABLE");

    function handleScan(value) {
        const scanType = scannerType;
        setScannerType("");
        if (scanType === "employee") onScanEmployee(value);
        if (scanType === "book") onScanBook(value);
    }

    return (
        <section className="library-section" aria-labelledby="library-issue-title">
            <header className="library-section-header">
                <div>
                    <h2 id="library-issue-title">Issue book</h2>
                    <p>Select an employee and an available book to create an issue transaction.</p>
                </div>
            </header>

            <div className="library-flow-grid">
                <section className="library-flow-step" aria-labelledby="issue-employee-title">
                    <div className="library-step-heading">
                        <span className="library-step-number">01</span>
                        <h3 id="issue-employee-title">Employee</h3>
                    </div>
                    <div className="library-selection" aria-live="polite">
                        {employee ? (
                            <>
                                <strong>{employee.name || employee.fullName || "Employee"}</strong>
                                <span>Employee ID: {employee.id}</span>
                                {employee.email && <span>{employee.email}</span>}
                            </>
                        ) : (
                            <span className="library-muted">No employee selected</span>
                        )}
                    </div>
                    <button className="library-secondary-button" type="button" onClick={() => setScannerType("employee")}>
                        <UserRound size={17} aria-hidden="true" />
                        Scan employee QR
                    </button>
                    {employee && (
                        <button className="library-text-button" type="button" onClick={onViewTransactions}>
                            <History size={15} aria-hidden="true" />
                            View employee transactions
                        </button>
                    )}
                </section>

                <section className="library-flow-step" aria-labelledby="issue-book-title">
                    <div className="library-step-heading">
                        <span className="library-step-number">02</span>
                        <h3 id="issue-book-title">Book</h3>
                    </div>
                    <div className="library-selection" aria-live="polite">
                        {book ? (
                            <>
                                <strong>{book.title || "Untitled book"}</strong>
                                <span>{book.author || "Author not listed"}</span>
                                <span>Barcode: {book.barcode || "-"}</span>
                                <span className={`library-status-badge ${String(book.status).toUpperCase() === "AVAILABLE" ? "is-available" : "is-issued"}`}>{String(book.status || "UNKNOWN").toUpperCase()}</span>
                            </>
                        ) : (
                            <span className="library-muted">No book selected</span>
                        )}
                    </div>
                    <button className="library-secondary-button" type="button" onClick={() => setScannerType("book")}>
                        <ScanLine size={17} aria-hidden="true" />
                        Scan book barcode / QR
                    </button>
                </section>
            </div>

            {book && String(book.status).toUpperCase() === "ISSUED" && (
                <p className="library-inline-notice" role="status">Book is already issued.</p>
            )}

            <footer className="library-flow-footer">
                <button className="library-primary-button" type="button" disabled={!canIssue || submitting} onClick={onIssue}>
                    <BookOpenCheck size={17} aria-hidden="true" />
                    {submitting ? "Issuing..." : "Issue book"}
                </button>
            </footer>

            {scannerType && (
                <QRScanner
                    onScan={handleScan}
                    onClose={() => setScannerType("")}
                />
            )}
        </section>
    );
}

export default IssueBook;
