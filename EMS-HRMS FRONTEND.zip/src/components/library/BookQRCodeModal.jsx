import { useEffect, useRef, useState } from "react";
import { Download, Printer, X } from "lucide-react";
import BookQRCode from "./BookQRCode";

function BookQRCodeModal({ book, onClose }) {
    const printAreaRef = useRef(null);
    const [downloadError, setDownloadError] = useState("");
    const barcode = String(book?.barcode || "").trim();
    const bookId = book?.id ?? book?.bookId ?? "-";

    useEffect(() => {
        document.body.classList.add("library-qr-printing");
        return () => document.body.classList.remove("library-qr-printing");
    }, []);

    function downloadQr() {
        const canvas = printAreaRef.current?.querySelector("canvas");
        if (!canvas || !barcode) return;

        try {
            const link = document.createElement("a");
            link.download = `${barcode}-qr.png`;
            link.href = canvas.toDataURL("image/png");
            link.click();
            setDownloadError("");
        } catch (error) {
            console.error("Book QR download failed:", error);
            setDownloadError("Unable to download this QR code. Please try printing it instead.");
        }
    }

    return (
        <div
            className="library-modal-backdrop library-qr-backdrop"
            role="presentation"
            onMouseDown={(event) => {
                if (event.target === event.currentTarget) onClose();
            }}
        >
            <section
                className="library-book-modal library-qr-dialog"
                role="dialog"
                aria-modal="true"
                aria-labelledby="library-qr-modal-title"
            >
                <header className="library-modal-header library-qr-modal-header">
                    <div>
                        <p className="library-eyebrow">CMS Library</p>
                        <h2 id="library-qr-modal-title">Book QR Code</h2>
                    </div>
                    <button
                        className="library-icon-button"
                        type="button"
                        onClick={onClose}
                        aria-label="Close book QR code"
                    >
                        <X size={19} aria-hidden="true" />
                    </button>
                </header>

                <div className="library-qr-print-area" ref={printAreaRef}>
                    <p className="library-qr-print-brand">CMS LIBRARY</p>
                    <div className="library-qr-book-details">
                        <h3>{book?.title || "Untitled book"}</h3>
                        <p>{book?.author || "Author not listed"}</p>
                    </div>
                    <BookQRCode barcode={barcode} />
                    <p className="library-qr-book-id">Book ID: {bookId}</p>
                </div>

                {downloadError && <p className="library-qr-error" role="alert">{downloadError}</p>}

                <footer className="library-qr-actions">
                    <button
                        className="library-secondary-button"
                        type="button"
                        onClick={downloadQr}
                        disabled={!barcode}
                    >
                        <Download size={17} aria-hidden="true" />
                        Download QR
                    </button>
                    <button
                        className="library-primary-button"
                        type="button"
                        onClick={() => window.print()}
                        disabled={!barcode}
                    >
                        <Printer size={17} aria-hidden="true" />
                        Print QR
                    </button>
                    <button className="library-secondary-button" type="button" onClick={onClose}>
                        Close
                    </button>
                </footer>
            </section>
        </div>
    );
}

export default BookQRCodeModal;
