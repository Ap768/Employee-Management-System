import { useEffect, useRef, useState } from "react";
import { BrowserMultiFormatReader } from "@zxing/browser";
import { Camera, Square, X } from "lucide-react";

function QRScanner({ onScan, onClose }) {
    const videoRef = useRef(null);
    const controlsRef = useRef(null);
    const sessionRef = useRef(0);
    const hasScannedRef = useRef(false);
    const onScanRef = useRef(onScan);
    const onCloseRef = useRef(onClose);
    const [scanning, setScanning] = useState(false);
    const [error, setError] = useState("");

    useEffect(() => {
        onScanRef.current = onScan;
        onCloseRef.current = onClose;
    }, [onScan, onClose]);

    useEffect(() => {
        return () => {
            sessionRef.current += 1;
            controlsRef.current?.stop();
            controlsRef.current = null;
        };
    }, []);

    async function startScanner() {
        const sessionId = ++sessionRef.current;
        hasScannedRef.current = false;
        setError("");
        setScanning(true);

        try {
            const reader = new BrowserMultiFormatReader();
            const devices = await BrowserMultiFormatReader.listVideoInputDevices();
            if (sessionRef.current !== sessionId) return;
            if (!devices.length) throw new Error("No camera was found on this device.");

            const selectedDevice = devices.find((device) =>
                /back|rear|environment/i.test(device.label)
            ) || devices[0];
            const controls = await reader.decodeFromVideoDevice(
                selectedDevice.deviceId,
                videoRef.current,
                (result) => {
                    if (!result || sessionRef.current !== sessionId || hasScannedRef.current) return;

                    hasScannedRef.current = true;
                    controlsRef.current?.stop();
                    controlsRef.current = null;
                    setScanning(false);
                    onScanRef.current(result.getText());
                }
            );

            if (sessionRef.current !== sessionId) {
                controls.stop();
            } else {
                controlsRef.current = controls;
            }
        } catch (scanError) {
            if (sessionRef.current !== sessionId) return;
            setScanning(false);
            setError(
                scanError.name === "NotAllowedError"
                    ? "Camera permission was denied. Allow camera access and try again."
                    : scanError.message || "Unable to start the camera. Check camera permissions and try again."
            );
        }
    }

    function stopScanner() {
        sessionRef.current += 1;
        controlsRef.current?.stop();
        controlsRef.current = null;
        setScanning(false);
    }

    function closeScanner() {
        stopScanner();
        onCloseRef.current();
    }

    return (
        <div className="library-scanner-backdrop" role="presentation" onMouseDown={(event) => {
            if (event.target === event.currentTarget) closeScanner();
        }}>
            <section className="library-scanner-dialog" role="dialog" aria-modal="true" aria-labelledby="scanner-title">
                <div className="library-scanner-heading">
                    <div>
                        <p className="library-eyebrow">Camera input</p>
                        <h2 id="scanner-title">Scan QR or barcode</h2>
                    </div>
                    <button className="library-icon-button" type="button" onClick={closeScanner} aria-label="Close scanner">
                        <X size={19} aria-hidden="true" />
                    </button>
                </div>
                <div className="library-camera-frame">
                    <video className="library-scanner-video" ref={videoRef} muted playsInline autoPlay />
                    {!scanning && <span className="library-camera-placeholder">Camera is stopped</span>}
                </div>
                <p className={`library-scanner-status ${error ? "has-error" : ""}`} role={error ? "alert" : "status"}>
                    {error || (scanning ? "Position a code inside the camera view." : "Start the camera when you are ready to scan.")}
                </p>
                <div className="library-scanner-actions">
                    {scanning ? (
                        <button className="library-secondary-button" type="button" onClick={stopScanner}>
                            <Square size={16} aria-hidden="true" />
                            Stop scanner
                        </button>
                    ) : (
                        <button className="library-primary-button" type="button" onClick={startScanner}>
                            <Camera size={17} aria-hidden="true" />
                            Start scanner
                        </button>
                    )}
                    <button className="library-secondary-button" type="button" onClick={closeScanner}>Close</button>
                </div>
            </section>
        </div>
    );
}

export default QRScanner;