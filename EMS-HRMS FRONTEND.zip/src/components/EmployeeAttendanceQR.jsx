import { useEffect } from "react";
import { QRCodeSVG } from "qrcode.react";
import { X } from "lucide-react";
import "./EmployeeAttendanceQR.css";

function EmployeeAttendanceQR({ employee, onClose }) {
    useEffect(() => {
        function closeOnEscape(event) {
            if (event.key === "Escape") {
                onClose();
            }
        }

        window.addEventListener("keydown", closeOnEscape);

        return () => {
            window.removeEventListener("keydown", closeOnEscape);
        };
    }, [onClose]);

    // Employee must have a permanent QR token
    if (!employee?.qrToken) {
        return null;
    }

    // IMPORTANT:
    // The QR contains ONLY the permanent qrToken.
    // Admin/HR scanner will send this token to:
    // POST /api/attendance/scan
    const qrValue = employee.qrToken;

    return (
        <div
            className="employee-qr-backdrop"
            onClick={(event) => {
                if (event.target === event.currentTarget) {
                    onClose();
                }
            }}
        >
            <section
                className="employee-qr-dialog"
                role="dialog"
                aria-modal="true"
                aria-labelledby="employee-qr-dialog-title"
            >
                <button
                    className="employee-qr-close-button"
                    type="button"
                    onClick={onClose}
                    aria-label="Close attendance QR"
                >
                    <X size={20} aria-hidden="true" />
                </button>

                <p className="employee-qr-eyebrow">
                    Employee identity
                </p>

                <h2 id="employee-qr-dialog-title">
                    My Attendance QR
                </h2>

                <div className="employee-qr-code-frame">
                    <QRCodeSVG
                        value={qrValue}
                        size={220}
                        level="H"
                    />
                </div>

                <p className="employee-qr-instructions">
                    Show this QR code to Admin/HR for attendance.
                </p>

                <button
                    className="employee-qr-dismiss-button"
                    type="button"
                    onClick={onClose}
                >
                    Close
                </button>
            </section>
        </div>
    );
}

export default EmployeeAttendanceQR;