import { useEffect, useRef, useState } from "react";
import { BrowserMultiFormatReader } from "@zxing/browser";
import { Camera, CircleCheck, RotateCcw, Square } from "lucide-react";
import { scanEmployeeQr } from "../services/attendanceService";

function getResponseData(response) {
    const data = response?.data?.data ?? response?.data ?? {};
    return typeof data === "object" && data !== null ? data : {};
}

function getErrorMessage(error) {
    const data = error.response?.data;
    if (typeof data === "string") return data;
    return data?.message || data?.error || error.message || "Unable to record attendance.";
}

function getQrToken(value) {
    const text = value.trim();
    if (!text) return "";

    try {
        const payload = JSON.parse(text);
        if (typeof payload === "string") return payload.trim();
        if (typeof payload?.qrToken === "string") return payload.qrToken.trim();
        if (typeof payload?.token === "string") return payload.token.trim();
    } catch {
        // Existing employee QR codes may contain raw token text rather than JSON.
    }

    return text;
}

function EmployeeAttendanceScanner({ onScanSuccess }) {
    const videoRef = useRef(null);
    const readerRef = useRef(null);
    const controlsRef = useRef(null);
    const sessionRef = useRef(0);
    const handledResultRef = useRef(false);
    const lastScannedTokenRef = useRef("");
    const lastScannedTimeRef = useRef(0);
    const [scanning, setScanning] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [scanResult, setScanResult] = useState(null);
    const [error, setError] = useState("");

    function stopScanner() {
        sessionRef.current += 1;

        try {
            if (controlsRef.current) {
                controlsRef.current.stop();
                controlsRef.current = null;
            } else {
                readerRef.current?.reset();
            }
        } catch (stopError) {
            console.error("Scanner stop error:", stopError);
        }

        readerRef.current = null;
        setScanning(false);
    }

    async function submitScannedQr(value, sessionId) {
        const qrToken = getQrToken(value);
        if (!qrToken) {
            setError("The QR code does not contain an attendance token.");
            stopScanner();
            return;
        }

        const now = Date.now();
        if (
            lastScannedTokenRef.current === qrToken &&
            now - lastScannedTimeRef.current < 10000
        ) {
            return;
        }

        lastScannedTokenRef.current = qrToken;
        lastScannedTimeRef.current = now;

        handledResultRef.current = true;
        stopScanner();
        setSubmitting(true);
        setError("");

        try {
            const response = await scanEmployeeQr(qrToken);
            if (sessionRef.current !== sessionId + 1) return;

            const data = getResponseData(response);
            setScanResult({
                employeeName:
                    data.employeeName ||
                    data.employee?.name ||
                    data.name ||
                    "Employee",
                employeeId:
                    data.employeeId ??
                    data.employee?.id ??
                    data.id ??
                    "--",
                action:
                    data.action ||
                    data.attendanceAction ||
                    (data.checkOutTime ? "CHECK_OUT" : "CHECK_IN"),
                time: data.time || data.checkInTime || data.checkOutTime || null,
                workingHours: data.workingHours || null,
            });
            onScanSuccess?.(data);
        } catch (scanError) {
            if (sessionRef.current !== sessionId + 1) return;
            setError(getErrorMessage(scanError));
        } finally {
            setSubmitting(false);
        }
    }

    async function startScanner() {
        const sessionId = ++sessionRef.current;
        setError("");
        setScanResult(null);
        handledResultRef.current = false;
        setScanning(true);

        try {
            const codeReader = new BrowserMultiFormatReader();
            readerRef.current = codeReader;
            const devices = await BrowserMultiFormatReader.listVideoInputDevices();

            if (sessionRef.current !== sessionId) return;
            if (!devices.length) {
                throw new Error("No camera found on this device.");
            }

            const rearCamera = devices.find((device) =>
                /back|rear|environment/i.test(device.label)
            );
            const selectedDeviceId =
                rearCamera?.deviceId || devices[devices.length - 1].deviceId;
            const controls = await codeReader.decodeFromVideoDevice(
                selectedDeviceId || undefined,
                videoRef.current,
                (result) => {
                    if (
                        !result ||
                        sessionRef.current !== sessionId ||
                        handledResultRef.current
                    ) {
                        return;
                    }

                    void submitScannedQr(result.getText(), sessionId);
                }
            );

            if (sessionRef.current !== sessionId) {
                controls.stop();
                return;
            }

            controlsRef.current = controls;
        } catch (scannerError) {
            if (sessionRef.current !== sessionId) return;

            console.error("Scanner error:", scannerError);
            setError(scannerError.message || "Unable to access camera.");
            stopScanner();
        }
    }

    useEffect(() => () => {
        sessionRef.current += 1;
        controlsRef.current?.stop();
        readerRef.current?.reset();
    }, []);

    useEffect(() => {
        if (!scanResult) {
            return;
        }

        const timer = setTimeout(() => {
            startScanner();
        }, 3000);

        return () => {
            clearTimeout(timer);
        };

        // startScanner intentionally omitted because it is recreated on render.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [scanResult]);

    const alreadyCompleted = /already.*(complete|check.?out)|checked out/i.test(error);

    return (
        <section className="employee-attendance-scanner" aria-labelledby="scanner-title">
            <header className="scanner-header">
                <div>
                    <p className="scanner-eyebrow">Attendance</p>
                    <h3 id="scanner-title">QR Attendance Scanner</h3>
                </div>
            </header>

            {!scanning && !submitting && !scanResult && (
                <button
                    type="button"
                    className="scanner-start-button"
                    onClick={startScanner}
                >
                    <Camera size={18} aria-hidden="true" />
                    Open Scanner
                </button>
            )}

            {scanning && (
                <div className="scanner-camera-container">
                    <video
                        ref={videoRef}
                        className="scanner-video"
                        autoPlay
                        muted
                        playsInline
                    />
                    <div className="scanner-frame" aria-hidden="true" />
                    <p className="scanner-hint">Scan the employee's permanent QR code.</p>
                    <button
                        type="button"
                        className="scanner-stop-button"
                        onClick={stopScanner}
                    >
                        <Square size={16} aria-hidden="true" />
                        Stop Scanner
                    </button>
                </div>
            )}

            {submitting && (
                <p className="scanner-hint" role="status">
                    Recording attendance...
                </p>
            )}

            {error && (
                <p className="scanner-error" role="alert">
                    {alreadyCompleted && <strong>Attendance Already Completed. </strong>}
                    {error}
                </p>
            )}

            {scanResult && (
                <div className="scanner-result" aria-live="polite">
                    <div className="scanner-success-icon">
                        <CircleCheck size={26} aria-hidden="true" />
                    </div>
                    <h4>Attendance Successful</h4>
                    <dl className="scanner-employee-details">
                        <div>
                            <dt>Employee</dt>
                            <dd>{scanResult.employeeName}</dd>
                        </div>
                        <div>
                            <dt>Employee ID</dt>
                            <dd>{scanResult.employeeId}</dd>
                        </div>
                        <div>
                            <dt>Action</dt>
                            <dd>{String(scanResult.action).replaceAll("_", "-")}</dd>
                        </div>
                        <div>
                            <dt>Time</dt>
                            <dd>
                                {scanResult.time
                                    ? new Date(scanResult.time).toLocaleTimeString([], {
                                          hour: "2-digit",
                                          minute: "2-digit",
                                      })
                                    : "-"}
                            </dd>
                        </div>
                        {scanResult.workingHours && (
                            <div>
                                <dt>Working Hours</dt>
                                <dd>{scanResult.workingHours}</dd>
                            </div>
                        )}
                    </dl>
                    <button
                        type="button"
                        className="scanner-rescan-button"
                        onClick={startScanner}
                    >
                        <RotateCcw size={17} aria-hidden="true" />
                        Scan Another Employee
                    </button>
                </div>
            )}

            {error && !scanning && (
                <button
                    type="button"
                    className="scanner-rescan-button"
                    onClick={startScanner}
                >
                    <RotateCcw size={17} aria-hidden="true" />
                    Try Again
                </button>
            )}
        </section>
    );
}

export default EmployeeAttendanceScanner;
