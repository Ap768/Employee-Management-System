import { useEffect, useState } from "react";
import { BookOpen, BookPlus, CircleCheck, Clock3, RefreshCw, X } from "lucide-react";
import { toast } from "react-toastify";
import BookTable from "../../components/library/BookTable";
import BookQRCodeModal from "../../components/library/BookQRCodeModal";
import IssueBook from "../../components/library/IssueBook";
import ReturnBook from "../../components/library/ReturnBook";
import TransactionTable from "../../components/library/TransactionTable";
import {
    createBook,
    deleteBook,
    getBookByBarcode,
    getBooks,
    getEmployeeByQrToken,
    getEmployeeTransactions,
    getLibraryErrorMessage,
    getTransactions,
    issueBook as issueBookRequest,
    returnBook as returnBookRequest,
    updateBook,
} from "../../services/libraryService";
import { hasAdminAccess } from "../../utils/roleUtils";
import "./Library.css";

function getResponseData(response) {
    return response?.data?.data ?? response?.data ?? response ?? {};
}

function getResponseList(response, keys) {
    const data = getResponseData(response);
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.content)) return data.content;
    for (const key of keys) {
        if (Array.isArray(data?.[key])) return data[key];
    }
    return [];
}

function getQrToken(value) {
    const text = String(value || "").trim();
    if (!text) return "";
    try {
        const payload = JSON.parse(text);
        if (typeof payload === "string") return payload.trim();
        return String(payload?.qrToken || payload?.token || "").trim() || text;
    } catch {
        return text;
    }
}

function normalizeEmployee(data) {
    const employee = data?.employee || data;
    const id = employee?.id ?? employee?.employeeId;
    if (id === undefined || id === null) return null;
    return {
        ...employee,
        id,
        name: employee.name || employee.fullName || employee.employeeName || "Employee",
    };
}

function Library({ role }) {
    const [books, setBooks] = useState([]);
    const [transactions, setTransactions] = useState([]);
    const [loadingBooks, setLoadingBooks] = useState(true);
    const [loadingTransactions, setLoadingTransactions] = useState(true);
    const [savingBook, setSavingBook] = useState(false);
    const [issuing, setIssuing] = useState(false);
    const [returning, setReturning] = useState(false);
    const [bookModalOpen, setBookModalOpen] = useState(false);
    const [qrBook, setQrBook] = useState(null);
    const [employee, setEmployee] = useState(null);
    const [issueBook, setIssueBook] = useState(null);
    const [returnBook, setReturnBook] = useState(null);
    const [editingBook, setEditingBook] = useState(null);
    const [transactionFilter, setTransactionFilter] = useState("");
    const [bookForm, setBookForm] = useState({
        title: "",
        author: "",
        isbn: "",
        barcode: "",
        category: "",
    });

    async function loadBooks() {
        try {
            const response = await getBooks();
            setBooks(getResponseList(response, ["books"]));
        } catch (error) {
            toast.error(getLibraryErrorMessage(error, "Unable to load books."));
        } finally {
            setLoadingBooks(false);
        }
    }

    async function loadTransactions() {
        try {
            const response = await getTransactions();
            setTransactions(getResponseList(response, ["transactions"]));
            setTransactionFilter("");
        } catch (error) {
            toast.error(getLibraryErrorMessage(error, "Unable to load transactions."));
        } finally {
            setLoadingTransactions(false);
        }
    }

    function refreshLibraryData() {
        setLoadingBooks(true);
        setLoadingTransactions(true);
        return Promise.all([loadBooks(), loadTransactions()]);
    }

    useEffect(() => {
        let active = true;

        getBooks()
            .then((response) => {
                if (active) setBooks(getResponseList(response, ["books"]));
            })
            .catch((error) => {
                if (active) toast.error(getLibraryErrorMessage(error, "Unable to load books."));
            })
            .finally(() => {
                if (active) setLoadingBooks(false);
            });

        getTransactions()
            .then((response) => {
                if (active) setTransactions(getResponseList(response, ["transactions"]));
            })
            .catch((error) => {
                if (active) toast.error(getLibraryErrorMessage(error, "Unable to load transactions."));
            })
            .finally(() => {
                if (active) setLoadingTransactions(false);
            });

        return () => {
            active = false;
        };
    }, []);

    const availableCount = books.filter((book) => String(book.status).toUpperCase() === "AVAILABLE").length;
    const issuedCount = books.filter((book) => String(book.status).toUpperCase() === "ISSUED").length;

    async function handleEmployeeScan(value) {
        const qrToken = getQrToken(value);
        if (!qrToken) {
            toast.error("The scanned QR code does not contain an employee token.");
            return;
        }
        try {
            const response = await getEmployeeByQrToken(qrToken);
            const foundEmployee = normalizeEmployee(getResponseData(response));
            if (!foundEmployee) {
                toast.error("The QR code did not match an employee.");
                return;
            }
            setEmployee(foundEmployee);
            toast.success(`Employee identified: ${foundEmployee.name}`);
        } catch (error) {
            toast.error(getLibraryErrorMessage(error, "Unable to identify this employee QR code."));
        }
    }

    async function findBookByBarcode(barcode, setBook, flow) {
        const normalizedBarcode = String(barcode || "").trim();
        if (!normalizedBarcode) {
            toast.error("The scanned code is empty.");
            return;
        }
        try {
            const response = await getBookByBarcode(normalizedBarcode);
            const foundBook = getResponseData(response)?.book || getResponseData(response);
            if (!foundBook?.barcode) {
                toast.error("No book was found for this barcode.");
                return;
            }
            setBook(foundBook);
            if (flow === "issue" && String(foundBook.status).toUpperCase() === "ISSUED") {
                toast.warning("Book is already issued.");
            }
            if (flow === "return" && String(foundBook.status).toUpperCase() === "AVAILABLE") {
                toast.warning("Book is already available.");
            }
        } catch (error) {
            toast.error(getLibraryErrorMessage(error, "Book not found."));
        }
    }

    async function handleIssue() {
        if (!employee?.id || !issueBook?.barcode || String(issueBook.status).toUpperCase() !== "AVAILABLE") return;
        setIssuing(true);
        try {
            await issueBookRequest(employee.id, issueBook.barcode);
            toast.success("Book issued successfully.");
            setEmployee(null);
            setIssueBook(null);
            await Promise.all([loadBooks(), loadTransactions()]);
        } catch (error) {
            toast.error(getLibraryErrorMessage(error, "Unable to issue this book."));
        } finally {
            setIssuing(false);
        }
    }

    async function handleReturn() {
        if (!returnBook?.barcode || String(returnBook.status).toUpperCase() !== "ISSUED") return;
        setReturning(true);
        try {
            await returnBookRequest(returnBook.barcode);
            toast.success("Book returned successfully.");
            setReturnBook(null);
            await Promise.all([loadBooks(), loadTransactions()]);
        } catch (error) {
            toast.error(getLibraryErrorMessage(error, "Unable to return this book."));
        } finally {
            setReturning(false);
        }
    }

    function openBookForm(book = null) {
        setEditingBook(book);
        setBookModalOpen(true);
        setBookForm({
            title: book?.title || "",
            author: book?.author || "",
            isbn: book?.isbn || "",
            barcode: book?.barcode || "",
            category: book?.category || "",
        });
    }

    async function handleBookSave(event) {
        event.preventDefault();
        setSavingBook(true);
        const payload = {
            ...bookForm,
            ...(editingBook?.status ? { status: editingBook.status } : {}),
        };
        try {
            if (editingBook) {
                await updateBook(editingBook.id ?? editingBook.bookId, payload);
                toast.success("Book updated successfully.");
            } else {
                await createBook(payload);
                toast.success("Book added successfully.");
            }
            setEditingBook(null);
            setBookModalOpen(false);
            await loadBooks();
        } catch (error) {
            toast.error(getLibraryErrorMessage(error, "Unable to save this book."));
        } finally {
            setSavingBook(false);
        }
    }

    async function handleBookDelete(book) {
        if (!window.confirm(`Delete "${book.title || "this book"}"?`)) return;
        try {
            await deleteBook(book.id ?? book.bookId);
            toast.success("Book deleted successfully.");
            await loadBooks();
        } catch (error) {
            toast.error(getLibraryErrorMessage(error, "Unable to delete this book."));
        }
    }

    async function handleViewEmployeeTransactions() {
        if (!employee?.id) return;
        setLoadingTransactions(true);
        try {
            const response = await getEmployeeTransactions(employee.id);
            setTransactions(getResponseList(response, ["transactions"]));
            setTransactionFilter(employee.name);
            document.getElementById("transactions")?.scrollIntoView({ behavior: "smooth" });
        } catch (error) {
            toast.error(getLibraryErrorMessage(error, "Unable to load this employee's transactions."));
        } finally {
            setLoadingTransactions(false);
        }
    }

    return (
        <section className="library-page">
            <header className="library-page-header">
                <div>
                    <p className="library-eyebrow">Library management</p>
                    <h1>Library</h1>
                    <p className="library-page-copy">Manage books, circulation, and transaction history.</p>
                </div>
                <button className="library-secondary-button" type="button" onClick={() => { void refreshLibraryData(); }}>
                    <RefreshCw size={17} aria-hidden="true" />
                    Refresh data
                </button>
            </header>

            <section className="library-overview" aria-label="Library overview">
                <article className="library-metric">
                    <span className="library-metric-icon"><BookOpen size={18} aria-hidden="true" /></span>
                    <span className="library-metric-label">Catalogue</span>
                    <strong>{loadingBooks ? "—" : books.length}</strong>
                    <small>Total books</small>
                </article>
                <article className="library-metric">
                    <span className="library-metric-icon is-green"><CircleCheck size={18} aria-hidden="true" /></span>
                    <span className="library-metric-label">Available</span>
                    <strong>{loadingBooks ? "—" : availableCount}</strong>
                    <small>Ready to issue</small>
                </article>
                <article className="library-metric">
                    <span className="library-metric-icon is-amber"><Clock3 size={18} aria-hidden="true" /></span>
                    <span className="library-metric-label">On loan</span>
                    <strong>{loadingBooks ? "—" : issuedCount}</strong>
                    <small>Currently issued</small>
                </article>
            </section>

            <div id="books" className="library-anchor">
                <BookTable
                    books={books}
                    loading={loadingBooks}
                    canDelete={hasAdminAccess(role)}
                    onAddBook={() => openBookForm()}
                    onEditBook={openBookForm}
                    onDeleteBook={handleBookDelete}
                    onViewQr={setQrBook}
                />
            </div>

            <div id="issue-return" className="library-workflow-grid library-anchor">
                <IssueBook
                    employee={employee}
                    book={issueBook}
                    submitting={issuing}
                    onScanEmployee={handleEmployeeScan}
                    onScanBook={(barcode) => findBookByBarcode(barcode, setIssueBook, "issue")}
                    onIssue={handleIssue}
                    onViewTransactions={handleViewEmployeeTransactions}
                />
                <ReturnBook
                    book={returnBook}
                    submitting={returning}
                    onScanBook={(barcode) => findBookByBarcode(barcode, setReturnBook, "return")}
                    onReturn={handleReturn}
                />
            </div>

            <div id="transactions" className="library-anchor">
                <TransactionTable
                    transactions={transactions}
                    loading={loadingTransactions}
                    filterLabel={transactionFilter}
                    onShowAll={loadTransactions}
                />
            </div>

            {bookModalOpen && (
                <div className="library-modal-backdrop" role="presentation" onMouseDown={(event) => {
                    if (event.target === event.currentTarget) setBookModalOpen(false);
                }}>
                    <section className="library-book-modal" role="dialog" aria-modal="true" aria-labelledby="library-book-modal-title">
                        <header className="library-modal-header">
                            <div>
                                <p className="library-eyebrow">Book catalogue</p>
                                <h2 id="library-book-modal-title">{editingBook ? "Edit book" : "Add book"}</h2>
                            </div>
                            <button className="library-icon-button" type="button" onClick={() => setBookModalOpen(false)} aria-label="Close book form"><X size={19} /></button>
                        </header>
                        <form className="library-book-form" onSubmit={handleBookSave}>
                            {[
                                ["title", "Title", true],
                                ["author", "Author", true],
                                ["isbn", "ISBN", false],
                                ["barcode", "Barcode", true],
                                ["category", "Category", false],
                            ].map(([field, label, required]) => (
                                <label className="library-form-field" key={field}>
                                    <span>{label}{required ? " *" : ""}</span>
                                    <input
                                        required={required}
                                        value={bookForm[field]}
                                        onChange={(event) => setBookForm((form) => ({ ...form, [field]: event.target.value }))}
                                    />
                                </label>
                            ))}
                            <div className="library-modal-actions">
                                <button className="library-secondary-button" type="button" onClick={() => setBookModalOpen(false)}>Cancel</button>
                                <button className="library-primary-button" type="submit" disabled={savingBook}>
                                    <BookPlus size={17} aria-hidden="true" />
                                    {savingBook ? "Saving..." : editingBook ? "Save changes" : "Add book"}
                                </button>
                            </div>
                        </form>
                    </section>
                </div>
            )}

            {qrBook && (
                <BookQRCodeModal
                    book={qrBook}
                    onClose={() => setQrBook(null)}
                />
            )}
        </section>
    );
}

export default Library;