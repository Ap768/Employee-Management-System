import { useEffect, useState } from "react";
import { QrCode } from "lucide-react";
import { getMyProfile } from "../services/employeeService";
import EmployeeAttendanceQR from "../components/EmployeeAttendanceQR";
import "./EmployeeProfile.css";

function EmployeeProfile() {
    const [employee, setEmployee] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [showQr, setShowQr] = useState(false);

    useEffect(() => {
        let isCurrent = true;

        async function loadEmployeeProfile() {
            try {
                const response = await getMyProfile();

                if (isCurrent) {
                    setEmployee(response.data);
                }
            } catch (loadError) {
                console.error("Employee profile error:", loadError);

                if (isCurrent) {
                    setError(
                        loadError.response?.data?.message ||
                        loadError.message ||
                        "Unable to load your profile."
                    );
                }
            } finally {
                if (isCurrent) setLoading(false);
            }
        }

        loadEmployeeProfile();
        return () => {
            isCurrent = false;
        };
    }, []);

    if (loading) {
        return (
            <div className="employee-profile-state" role="status">
                <span className="spinner-border" aria-hidden="true" />
                <p>Loading your profile...</p>
            </div>
        );
    }

    if (error) {
        return (
            <section className="employee-profile-page">
                <h2>Employee Profile</h2>
                <p className="employee-profile-error" role="alert">{error}</p>
            </section>
        );
    }

    return (
        <section className="employee-profile-page">
            <header className="employee-profile-heading">
                <p className="employee-profile-eyebrow">Your account</p>
                <h2>Employee Profile</h2>
            </header>

            <div className="employee-profile-details">
                <div className="employee-profile-avatar" aria-hidden="true">
                    {(employee.name || "E").trim().charAt(0).toUpperCase()}
                </div>
                <div className="employee-profile-identity">
                    <h3>{employee.name || employee.employeeName || "Employee"}</h3>
                    <p>{employee.email || employee.employeeEmail}</p>
                </div>
                <dl className="employee-profile-fields">
                    <div>
                        <dt>Employee ID</dt>
                        <dd>{employee.id ?? employee.employeeId ?? "Not provided"}</dd>
                    </div>
                    <div>
                        <dt>Department</dt>
                        <dd>{employee.department || "Not provided"}</dd>
                    </div>
                </dl>
            </div>

            <section className="employee-qr-card" aria-label="Employee attendance QR">
                <div>
                    <p className="employee-qr-eyebrow">Attendance</p>
                    <p className="employee-profile-qr-copy">
                        Show your employee QR to Admin or HR.
                    </p>
                </div>
                <button
                    className="employee-qr-open-button"
                    type="button"
                    onClick={() => setShowQr(true)}
                >
                    <QrCode size={18} aria-hidden="true" />
                    My Attendance QR
                </button>
            </section>
            {showQr && (
                <EmployeeAttendanceQR
                    employee={employee}
                    onClose={() => setShowQr(false)}
                />
            )}
        </section>
    );
}

export default EmployeeProfile;