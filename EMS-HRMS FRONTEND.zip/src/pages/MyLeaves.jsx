import { useEffect, useState } from "react";
import {
    getMyLeaves,
    cancelLeave,
    getLeaveBalance,
    getAllLeaves
} from "../services/leaveService";
import { toast } from "react-toastify";
import { normalizeRole } from "../utils/roleUtils";

function MyLeaves() {

    const [leaves, setLeaves] = useState([]);
    const [search, setSearch] = useState("");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [refreshKey, setRefreshKey] = useState(0);
    const email = localStorage.getItem("email") || "";
    const isAdmin = normalizeRole(localStorage.getItem("role")) === "ADMIN";

    const [balance, setBalance] = useState({
        casualLeave: 0,
        sickLeave: 0,
        earnedLeave: 0
    });

    useEffect(() => {
        let isCurrent = true;

        async function loadLeaves() {
            setLoading(true);
            setError("");

            try {
                const response = isAdmin
                    ? await getAllLeaves()
                    : await getMyLeaves(email);
                const data = response.data;
                const allLeaves = Array.isArray(data)
                    ? data
                    : Array.isArray(data?.content)
                        ? data.content
                        : null;

                if (!allLeaves) {
                    throw new Error("The leave service returned an invalid leave list.");
                }

                const ownLeaves = isAdmin
                    ? allLeaves.filter(
                        (leave) =>
                            String(leave.employeeEmail || "").trim().toLowerCase() ===
                            email.trim().toLowerCase()
                    )
                    : allLeaves;

                if (isCurrent) setLeaves(ownLeaves);
            } catch (loadError) {
                console.error("My leaves loading error:", loadError);
                if (isCurrent) {
                    const responseMessage =
                        loadError.response?.data?.message || loadError.response?.data;
                    setError(
                        (typeof responseMessage === "string" && responseMessage) ||
                        loadError.message ||
                        "Unable to load your leave records."
                    );
                }
            } finally {
                if (isCurrent) setLoading(false);
            }
        }

        async function loadBalance() {
            try {
                const response = await getLeaveBalance(email);
                if (isCurrent) setBalance(response.data);
            } catch (balanceError) {
                console.error("Leave balance loading error:", balanceError);
            }
        }

        loadLeaves();
        loadBalance();

        return () => {
            isCurrent = false;
        };
    }, [email, isAdmin, refreshKey]);

    function cancel(id) {

        if (!window.confirm("Cancel this leave?")) {
            return;
        }

        cancelLeave(id)
            .then(() => {

                toast.success("Leave cancelled successfully.");

                setRefreshKey((key) => key + 1);

            })
            .catch((error) => {
                console.log(error);
            });
    }

    const filteredLeaves = leaves.filter((leave) =>
        String(leave.leaveType || "")
            .toLowerCase()
            .includes(search.toLowerCase())
    );

    function statusBadge(status) {

        switch (status) {

            case "APPROVED":
                return <span className="status-pill status-pill--approved">Approved</span>;

            case "REJECTED":
                return <span className="status-pill status-pill--rejected">Rejected</span>;

            case "CANCELLED":
                return <span className="status-pill status-pill--cancelled">Cancelled</span>;

            default:
                return <span className="status-pill status-pill--pending">Pending</span>;
        }
    }

    return (

        <div className="employee-container page-fullwidth">

            <div className="employee-header mb-4">
                <p className="eyebrow">Leave dashboard</p>
                <h2 className="section-title">My Leaves</h2>
                <p className="section-copy">
                    Track your leave requests, review balances, and manage pending approvals from one place.
                </p>
            </div>

            <div className="balance-grid mb-5">
                <div className="balance-card balance-card--casual">
                    <p className="balance-label">Casual Leave</p>
                    <h2>{balance?.casualLeave ?? 0}</h2>
                    <p className="balance-copy">Available days</p>
                </div>
                <div className="balance-card balance-card--sick">
                    <p className="balance-label">Sick Leave</p>
                    <h2>{balance?.sickLeave ?? 0}</h2>
                    <p className="balance-copy">Available days</p>
                </div>
                <div className="balance-card balance-card--earned">
                    <p className="balance-label">Earned Leave</p>
                    <h2>{balance?.earnedLeave ?? 0}</h2>
                    <p className="balance-copy">Available days</p>
                </div>
            </div>

            <div className="table-panel">
                <div className="table-header">
                    <div>
                        <h3 className="subtitle">Leave history</h3>
                        <p className="section-copy">Search by leave type and cancel pending requests quickly.</p>
                    </div>
                    <input
                        className="search-input table-search"
                        placeholder="Search leave type..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>

                {error && <p className="text-danger" role="alert">{error}</p>}

                <div className="leave-table-wrapper">
                    <table className="leave-table">
                        <colgroup>
                            <col />
                            <col />
                            <col />
                            <col />
                            <col />
                        </colgroup>
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? (
                                <tr className="empty-row">
                                    <td colSpan={5}>Loading leave records...</td>
                                </tr>
                            ) : filteredLeaves.length > 0 ? (
                                filteredLeaves.map((leave) => (
                                    <tr key={leave.id}>
                                        <td>{leave.leaveType}</td>
                                        <td>{leave.fromDate}</td>
                                        <td>{leave.toDate}</td>
                                        <td>{statusBadge(leave.status)}</td>
                                        <td>
                                            {leave.status === "PENDING" && (
                                                <button
                                                    className="btn btn-danger btn-sm"
                                                    onClick={() => cancel(leave.id)}
                                                >
                                                    Cancel
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr className="empty-row">
                                    <td colSpan={5}>
                                        {error
                                            ? "Leave records could not be loaded."
                                            : isAdmin
                                                ? "No leave requests were found for this admin account."
                                                : "No leave records found. Apply for leave to see requests here."}
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    );

}

export default MyLeaves;