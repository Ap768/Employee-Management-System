import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import DashboardCard from "../components/DashboardCard";
import { fetchUpcomingHolidays } from "../store/slices/holidaySlice";
import { getAllEmployees } from "../services/employeeService";
import { hasManagementAccess } from "../utils/roleUtils";
import {
    Building2,
    CalendarDays,
    ClipboardList,
    UserPlus,
    UserRound,
    Users
} from "lucide-react";
import "./Dashboard.css";

function Dashboard({ role }) {

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const isManagementRole = hasManagementAccess(role);

    const [employees, setEmployees] = useState([]);
    const [employeeLoading, setEmployeeLoading] = useState(isManagementRole);
    const [employeeStatisticsAvailable, setEmployeeStatisticsAvailable] = useState(false);
    const { upcomingHolidays = [], loading: holidayLoading } = useSelector((state) => state.holiday);

    useEffect(() => {
        let isCurrent = true;

        async function loadEmployees() {
            try {
                const allEmployees = await getAllEmployees();
                if (isCurrent) {
                    setEmployees(allEmployees);
                    setEmployeeStatisticsAvailable(true);
                }
            } catch (error) {
                console.error("Dashboard employee loading error:", error);
            } finally {
                if (isCurrent) setEmployeeLoading(false);
            }
        }

        if (isManagementRole) {
            loadEmployees();
        }
        dispatch(fetchUpcomingHolidays());

        return () => {
            isCurrent = false;
        };
    }, [dispatch, role, isManagementRole]);

    const departmentStats = useMemo(() => {
        const counts = {};

        employees.forEach((employee) => {
            const department = employee?.department?.trim();
            if (!department) return;
            counts[department] = (counts[department] || 0) + 1;
        });

        return Object.entries(counts)
            .map(([name, count]) => ({ name, count }))
            .sort((a, b) => b.count - a.count);
    }, [employees]);

    const totalDepartments = departmentStats.length;

    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    const newEmployeesThisMonth = useMemo(() => {
        return employees.filter((employee) => {
            const candidateDate =
                employee?.createdAt ||
                employee?.createdDate ||
                employee?.dateCreated ||
                employee?.created_on ||
                employee?.createdAtDate;

            if (!candidateDate) return false;

            const date = new Date(candidateDate);

            if (Number.isNaN(date.getTime())) return false;

            return date.getFullYear() === currentYear && date.getMonth() === currentMonth;
        }).length;
    }, [employees, currentMonth, currentYear]);

    const upcomingHolidayList = useMemo(() => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        return [...upcomingHolidays]
            .filter((holiday) => {
                const holidayDate = new Date(holiday?.holidayDate || holiday?.date || holiday?.holiday_date);
                if (Number.isNaN(holidayDate.getTime())) return false;
                return holidayDate >= today;
            })
            .sort((a, b) => new Date(a?.holidayDate || a?.date || a?.holiday_date) - new Date(b?.holidayDate || b?.date || b?.holiday_date))
            .slice(0, 5);
    }, [upcomingHolidays]);

    const recentEmployees = useMemo(() => {
        return [...employees]
            .sort((a, b) => {
                const dateA = new Date(a?.createdAt || a?.createdDate || a?.dateCreated || 0).getTime();
                const dateB = new Date(b?.createdAt || b?.createdDate || b?.dateCreated || 0).getTime();
                return dateB - dateA;
            })
            .slice(0, 5);
    }, [employees]);

    const maxDepartmentEmployees = Math.max(...departmentStats.map((dept) => dept.count), 1);

    const loading = employeeLoading || holidayLoading;

    if (loading && employees.length === 0 && upcomingHolidays.length === 0) {
        return (
            <div className="loading-container">
                <div className="spinner-border loading-spinner" role="status"></div>
                <p className="loading-text">Loading Dashboard...</p>
            </div>
        );
    }

    if (!isManagementRole) {
        const employeeActions = [
            { label: "View My Profile", path: "/profile" },
            { label: "Apply for Leave", path: "/apply-leave" },
            { label: "View My Leaves", path: "/my-leaves" },
            { label: "View My Attendance", path: "/attendance" }
        ];
        const workspaceLinks = [
            { label: "My Attendance", path: "/attendance", icon: <CalendarDays size={20} aria-hidden="true" /> },
            { label: "Leave History", path: "/my-leaves", icon: <ClipboardList size={20} aria-hidden="true" /> },
            { label: "My Profile", path: "/profile", icon: <UserRound size={20} aria-hidden="true" /> }
        ];

        return (
            <div className="dashboard-page-container">
                <div className="dashboard-page-header">
                    <h1 className="dashboard-title">Dashboard</h1>
                    <p className="dashboard-subtitle">Welcome to your attendance &amp; leave management system</p>
                </div>

                <div className="dashboard-stats">
                    <div className="dashboard-card-wrapper employee-dashboard-card">
                        <DashboardCard
                            title="My Profile"
                            value="Profile"
                            icon={<UserRound size={20} aria-hidden="true" />}
                            bgColor="#3b82f6"
                            statusType="employees"
                        />
                        <button className="dashboard-link" onClick={() => navigate("/profile")} type="button">
                            View Profile →
                        </button>
                    </div>

                    <div className="dashboard-card-wrapper employee-dashboard-card">
                        <DashboardCard
                            title="Apply Leave"
                            value="Leave"
                            icon={<UserPlus size={20} aria-hidden="true" />}
                            bgColor="#10b981"
                            statusType="employees"
                        />
                        <button className="dashboard-link" onClick={() => navigate("/apply-leave")} type="button">
                            Apply Leave →
                        </button>
                    </div>

                    <div className="dashboard-card-wrapper employee-dashboard-card">
                        <DashboardCard
                            title="My Leaves"
                            value="Leaves"
                            icon={<ClipboardList size={20} aria-hidden="true" />}
                            bgColor="#8b5cf6"
                            statusType="employees"
                        />
                        <button className="dashboard-link" onClick={() => navigate("/my-leaves")} type="button">
                            View Leaves →
                        </button>
                    </div>

                    <div className="dashboard-card-wrapper employee-dashboard-card">
                        <DashboardCard
                            title="Upcoming Holidays"
                            value={upcomingHolidayList.length}
                            icon={<CalendarDays size={20} aria-hidden="true" />}
                            bgColor="#f59e0b"
                            statusType="employees"
                        />
                        <button className="dashboard-link" onClick={() => navigate("/holidays")} type="button">
                            View Holidays →
                        </button>
                    </div>
                </div>

                <section className="dashboard-panel employee-quick-actions">
                    <div className="panel-header">
                        <h3>Quick Actions</h3>
                    </div>
                    <div className="employee-action-list">
                        {employeeActions.map((action) => (
                            <button
                                className="employee-action-button"
                                key={action.path}
                                onClick={() => navigate(action.path)}
                                type="button"
                            >
                                {action.label}
                            </button>
                        ))}
                    </div>
                </section>

                <section className="dashboard-panel employee-workspace">
                    <div className="panel-header">
                        <h3>Employee Workspace</h3>
                    </div>
                    <div className="employee-workspace-grid">
                        {workspaceLinks.map((link) => (
                            <button
                                className="employee-workspace-link"
                                key={link.path}
                                onClick={() => navigate(link.path)}
                                type="button"
                            >
                                <span className="employee-workspace-icon">{link.icon}</span>
                                <span>{link.label}</span>
                            </button>
                        ))}
                    </div>
                </section>

                <section className="dashboard-panel employee-holidays">
                    <div className="panel-header">
                        <h3>Upcoming Holidays</h3>
                    </div>
                    <div className="holiday-list">
                        {upcomingHolidayList.length > 0 ? (
                            upcomingHolidayList.map((holiday) => {
                                const holidayDate = new Date(holiday?.holidayDate || holiday?.date || holiday?.holiday_date);
                                const formattedDate = holidayDate.toLocaleDateString("en-GB", {
                                    day: "2-digit",
                                    month: "short",
                                    year: "numeric"
                                });
                                const dayName = holidayDate.toLocaleDateString("en-US", { weekday: "long" });

                                return (
                                    <div key={holiday.id || `${holiday.name}-${formattedDate}`} className="holiday-item">
                                        <div className="holiday-name">{holiday.name || holiday.holidayName}</div>
                                        <div className="holiday-meta">{formattedDate} · {dayName}</div>
                                    </div>
                                );
                            })
                        ) : (
                            <p className="empty-state">No upcoming holidays.</p>
                        )}
                    </div>
                    <button className="dashboard-link" onClick={() => navigate("/holidays")} type="button">
                        View All Holidays →
                    </button>
                </section>
            </div>
        );
    }

    return (

        <div className="dashboard-page-container">

            <div className="dashboard-page-header">

                <h1 className="dashboard-title">Dashboard</h1>

                <p className="dashboard-subtitle">Welcome to your attendance & leave management system</p>

            </div>

            <div className="dashboard-stats">

                <div className="dashboard-card-wrapper">
                    <DashboardCard
                        title="Total Employees"
                        value={employeeStatisticsAvailable ? employees.length : "—"}
                        icon={<Users size={20} aria-hidden="true" />}
                        bgColor="#3b82f6"
                        statusType="employees"
                    />
                </div>

                <div className="dashboard-card-wrapper">
                    <DashboardCard
                        title="Total Departments"
                        value={totalDepartments}
                        icon={<Building2 size={20} aria-hidden="true" />}
                        bgColor="#8b5cf6"
                        statusType="employees"
                    />
                </div>

                <div className="dashboard-card-wrapper">
                    <DashboardCard
                        title="New Employees"
                        value={newEmployeesThisMonth}
                        icon={<UserPlus size={20} aria-hidden="true" />}
                        bgColor="#10b981"
                        statusType="employees"
                    />
                </div>

                <div className="dashboard-card-wrapper">
                    <DashboardCard
                        title="Upcoming Holidays"
                        value={upcomingHolidayList.length}
                        icon={<CalendarDays size={20} aria-hidden="true" />}
                        bgColor="#f59e0b"
                        statusType="employees"
                    />
                </div>

            </div>

            <div className="dashboard-sections">

                <section className="dashboard-panel">
                    <div className="panel-header">
                        <h3>Departments</h3>
                    </div>

                    <div className="department-list">
                        {departmentStats.length > 0 ? (
                            departmentStats.map((department) => {
                                const percent = (department.count / maxDepartmentEmployees) * 100;

                                return (
                                    <div key={department.name} className="department-row">
                                        <div className="department-label-row">
                                            <span className="department-name">{department.name}</span>
                                            <span className="department-count">{department.count} Employees</span>
                                        </div>

                                        <div className="department-progress-track">
                                            <div
                                                className="department-progress-bar"
                                                style={{ width: `${percent}%` }}
                                            />
                                        </div>
                                    </div>
                                );
                            })
                        ) : (
                            <p className="empty-state">No department data available.</p>
                        )}
                    </div>

                    <button className="dashboard-link" onClick={() => navigate("/employees")} type="button">
                        View All Employees →
                    </button>
                </section>

                <section className="dashboard-panel">
                    <div className="panel-header">
                        <h3>Upcoming Holidays</h3>
                    </div>

                    <div className="holiday-list">
                        {upcomingHolidayList.length > 0 ? (
                            upcomingHolidayList.map((holiday) => {
                                const holidayDate = new Date(holiday?.holidayDate || holiday?.date || holiday?.holiday_date);
                                const formattedDate = holidayDate.toLocaleDateString("en-GB", {
                                    day: "2-digit",
                                    month: "short",
                                    year: "numeric"
                                });
                                const dayName = holidayDate.toLocaleDateString("en-US", { weekday: "long" });

                                return (
                                    <div key={holiday.id || `${holiday.name}-${formattedDate}`} className="holiday-item">
                                        <div className="holiday-name">{holiday.name || holiday.holidayName}</div>
                                        <div className="holiday-meta">{formattedDate} · {dayName}</div>
                                    </div>
                                );
                            })
                        ) : (
                            <p className="empty-state">No upcoming holidays.</p>
                        )}
                    </div>

                    <button className="dashboard-link" onClick={() => navigate("/holidays")} type="button">
                        View All Holidays →
                    </button>
                </section>

            </div>

            <section className="dashboard-panel dashboard-panel-wide">
                <div className="panel-header">
                    <h3>Recent Employees</h3>
                </div>

                <div className="recent-employees-table">
                    <div className="recent-header-row">
                        <span>Name</span>
                        <span>Email</span>
                        <span>Department</span>
                        <span>Salary</span>
                    </div>

                    {recentEmployees.length > 0 ? (
                        recentEmployees.map((employee) => (
                            <div key={employee.id} className="recent-row">
                                <span>{employee.name}</span>
                                <span>{employee.email}</span>
                                <span>{employee.department}</span>
                                <span>₹{Number(employee.salary || 0).toLocaleString()}</span>
                            </div>
                        ))
                    ) : (
                        <p className="empty-state">No recent employees found.</p>
                    )}
                </div>

                <button className="dashboard-link" onClick={() => navigate("/employees")} type="button">
                    View All Employees →
                </button>
            </section>

        </div>

    );

}

export default Dashboard;