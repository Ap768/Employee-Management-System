    import { useEffect, useState } from "react";
    import api from "../api/axios";

    function Archive() {

        const [files, setFiles]
        = useState([]);

        useEffect(() => {

            fetchFiles();

        }, []);

        function fetchFiles() {

            api
                .get("/archive")

                .then((response) => {

                    setFiles(response.data);

                });

        }

        function deleteFile(id) {

            api
                .delete(
                    `/archive/${id}`
                )

                .then(() => {

                    alert("File Deleted");

                    fetchFiles();

                });

        }

        async function downloadFile(id) {
            try {
                const response = await api.get(`/archive/download/${id}`, {
                    responseType: "blob"
                });
                const downloadUrl = URL.createObjectURL(response.data);
                const link = document.createElement("a");
                link.href = downloadUrl;
                link.download =
                    files.find((file) => file.id === id)?.fileName || `archive-${id}`;
                link.click();
                URL.revokeObjectURL(downloadUrl);
            } catch (error) {
                console.error("Archive download failed:", error);
                alert("Unable to download archive file.");
            }
        }

        return (

            <div className="archive-container">

                <h2>Archive Files</h2>

                <table className="table">

                    <thead>

                        <tr>

                            <th>File Name</th>
                            <th>Uploaded At</th>
                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                        {

                            files.map((file) => (

                                <tr key={file.id}>

                                    <td>
                                        {file.fileName}
                                    </td>

                                    <td>
                                        {file.uploadedAt}
                                    </td>

                                    <td>

                                        <button
                                            className="btn btn-success me-2"
                                            onClick={() =>
                                                downloadFile(file.id)
                                            }
                                        >
                                            Download
                                        </button>

                                        <button
                                            className="btn btn-danger"
                                            onClick={() =>
                                                deleteFile(file.id)
                                            }
                                        >
                                            Delete
                                        </button>

                                    </td>

                                </tr>

                            ))

                        }

                    </tbody>

                </table>

            </div>

        );
    }

    export default Archive;