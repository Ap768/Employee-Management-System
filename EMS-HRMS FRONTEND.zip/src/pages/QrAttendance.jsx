import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { qrPunch } from "../services/attendanceService";
import { parseAttendanceQrPayload } from "../utils/attendanceQr";

function QrAttendance() {
    const [searchParams] = useSearchParams();
    const parsedPayload = parseAttendanceQrPayload(searchParams.get("data"));
    const payload = parsedPayload && !parsedPayload.expired ? parsedPayload : null;
    const [processing, setProcessing] = useState(false);
    const [completed, setCompleted] = useState(false);
    const [message, setMessage] = useState("");
    const initialMessage = !parsedPayload
        ? "Invalid attendance QR code."
        : parsedPayload.expired
            ? "This QR code has expired. Please ask the admin to generate a new QR code."
            : "";
    const displayMessage = message || initialMessage;

    async function handleConfirm() {
        if (!payload || processing || completed) {
            return;
        }

        if (payload.expiresAt < Date.now()) {
            setMessage("This QR code has expired. Please ask the admin to generate a new QR code.");
            return;
        }

        try {
            setProcessing(true);
            setMessage("Processing attendance...");
            await qrPunch(payload);
            setCompleted(true);
            setMessage(
                payload.action === "CHECK_IN"
                    ? "Attendance marked successfully. You are checked in."
                    : "Attendance marked successfully. You are checked out."
            );
        } catch (error) {
            const responseMessage =
                error?.response?.data?.message ||
                error?.response?.data ||
                error?.message ||
                "Unable to mark attendance.";
            setMessage(
                typeof responseMessage === "string"
                    ? responseMessage
                    : "Unable to mark attendance."
            );
        } finally {
            setProcessing(false);
        }
    }

    return (
        <main style={styles.container}>
            <section style={styles.card} aria-live="polite">
                {!payload ? (
                    <>
                        <h1 style={styles.heading}>Attendance QR</h1>
                        <p style={styles.error}>{displayMessage}</p>
                    </>
                ) : (
                    <>
                        <p style={styles.eyebrow}>EMS</p>
                        <h1 style={styles.heading}>Confirm attendance</h1>
                        <div style={styles.info}>
                            <span style={styles.label}>Employee</span>
                            <p style={styles.email}>{payload.email}</p>
                        </div>
                        <div style={styles.action}>
                            <span style={styles.label}>Action</span>
                            <p style={styles.actionText}>
                    l             {payload.action === "CHECK_IN" ? "CHECK IN" : "CHECK OUT"}
                            </p>
                        </div>
                        {displayMessage && (
                            <p style={completed ? styles.success : styles.error}>
                                {displayMessage}
                            </p>
                        )}
                        {!completed && (
                            <button
                                type="button"
                                onClick={handleConfirm}
                                disabled={processing}
                                style={styles.button}
                            >
                                {processing
                                    ? "Processing..."
                                    : payload.action === "CHECK_IN"
                                        ? "Confirm check in"
                                        : "Confirm check out"}
                            </button>
                        )}
                    </>
                )}
            </section>
        </main>
    );
}

const styles = {
    container: {
        minHeight: "100vh",
        display: "grid",
        placeItems: "center",
        padding: "20px",
        background: "linear-gradient(145deg, #edf4f3 0%, #f8faf9 55%, #e8efee 100%)",
    },
    card: {
        width: "100%",
        maxWidth: "420px",
        padding: "32px",
        background: "#ffffff",
        border: "1px solid #dce6e3",
        borderRadius: "8px",
        boxShadow: "0 16px 48px rgba(24, 58, 51, 0.12)",
        textAlign: "center",
    },
    eyebrow: {
        margin: "0 0 8px",
        color: "#117665",
        fontSize: "13px",
        fontWeight: 700,
        textTransform: "uppercase",
    },
    heading: {
        margin: "0 0 24px",
        color: "#183a33",
        fontSize: "24px",
        lineHeight: 1.25,
    },
    info: {
        marginBottom: "12px",
        padding: "16px",
        background: "#f4f7f6",
        borderRadius: "6px",
        overflowWrap: "anywhere",
    },
    label: {
        color: "#65736f",
        fontSize: "12px",
        fontWeight: 700,
        textTransform: "uppercase",
    },
    email: {
        margin: "6px 0 0",
        color: "#183a33",
        fontWeight: 600,
    },
    action: {
        marginBottom: "20px",
        padding: "16px",
        background: "#eaf4f1",
        borderRadius: "6px",
    },
    actionText: {
        margin: "6px 0 0",
        color: "#117665",
        fontSize: "22px",
        fontWeight: 700,
    },
    button: {
        width: "100%",
        minHeight: "48px",
        border: 0,
        borderRadius: "6px",
        background: "#117665",
        color: "#ffffff",
        fontSize: "16px",
        fontWeight: 700,
        cursor: "pointer",
    },
    success: {
        color: "#16754f",
        fontWeight: 600,
    },
    error: {
        color: "#b42318",
        fontWeight: 600,
    },
};

export default QrAttendance;