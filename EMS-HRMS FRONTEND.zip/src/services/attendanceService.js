import api from "../api/axios";

// =====================================================
// NORMAL EMPLOYEE CHECK-IN
// =====================================================

export const checkIn = (email) =>
    api.post(`/attendance/checkin/${email}`);


// =====================================================
// NORMAL EMPLOYEE CHECK-OUT
// =====================================================

export const checkOut = (email) =>
    api.put(`/attendance/checkout/${email}`);


// =====================================================
// OLD QR ATTENDANCE
// =====================================================
// Kept for the existing QR attendance flow.

export const qrPunch = (payload) =>
    api.post(`/attendance/qr-punch`, payload);


// =====================================================
// NEW PERMANENT EMPLOYEE QR SCANNER
// =====================================================
// Used by Admin / HR Attendance Management scanner.
//
// Backend automatically decides:
// - No attendance today  -> CHECK-IN
// - Checked in           -> CHECK-OUT
// - Already checked out  -> Error

export const scanEmployeeQr = (qrToken) =>
    api.post(`/attendance/scan`, {
        qrToken: qrToken
    });


// =====================================================
// TODAY'S ATTENDANCE
// =====================================================

export const getTodayAttendance = (email) =>
    api.get(`/attendance/today/${email}`);


// =====================================================
// ATTENDANCE HISTORY
// =====================================================

export const getAttendanceHistory = (email) =>
    api.get(`/attendance/history/${email}`);


// =====================================================
// ATTENDANCE BY DATE
// =====================================================

export const getAttendanceByDate = (email, date) =>
    api.get(`/attendance/date/${email}/${date}`);


// =====================================================
// ADMIN - ALL ATTENDANCE
// =====================================================

export const getAllAttendance = () =>
    api.get("/attendance");


// =====================================================
// ADMIN - ALL EMPLOYEES ATTENDANCE BY DATE
// =====================================================

export const getAllEmployeesAttendanceByDate = (date) =>
    api.get(`/attendance/management/${date}`);