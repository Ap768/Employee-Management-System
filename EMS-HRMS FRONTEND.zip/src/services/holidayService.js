import api from "../api/axios";

// Get All Holidays
export const getAllHolidays = () => {
    return api.get("/holidays");
};

// Get Upcoming Holidays
export const getUpcomingHolidays = () => {
    return api.get("/holidays/upcoming");
};

// Get Holiday By Id
export const getHolidayById = (id) => {
    return api.get(`/holidays/${id}`);
};

// Add Holiday
export const addHoliday = (holiday) => {
    return api.post("/holidays", holiday);
};

// Update Holiday
export const updateHoliday = (id, holiday) => {
    return api.put(`/holidays/${id}`, holiday);
};

// Delete Holiday
export const deleteHoliday = (id) => {
    return api.delete(`/holidays/${id}`);
};