import api from "../api/axios";

export const getEmployees = (page, size = 5) =>
    api.get(`/employees/pagination?page=${page}&size=${size}`);

export const getAllEmployees = async () => {
    const pageSize = 100;
    const firstResponse = await getEmployees(0, pageSize);
    const firstPage = firstResponse.data;

    if (Array.isArray(firstPage)) {
        return firstPage;
    }

    if (!Array.isArray(firstPage?.content)) {
        throw new Error("The employee response did not contain a paginated employee list.");
    }

    const reportedPages = Number(firstPage.totalPages);
    const totalElements = Number(firstPage.totalElements);
    const totalPages = Number.isInteger(reportedPages) && reportedPages >= 0
        ? reportedPages
        : Number.isFinite(totalElements)
            ? Math.ceil(totalElements / pageSize)
            : NaN;

    if (!Number.isInteger(totalPages) || totalPages < 0) {
        throw new Error("The employee response did not include valid pagination metadata.");
    }

    const pages = await Promise.all(
        Array.from({ length: Math.max(totalPages - 1, 0) }, (_, index) =>
            getEmployees(index + 1, pageSize)
        )
    );

    return [
        ...firstPage.content,
        ...pages.flatMap((response) => {
            if (Array.isArray(response.data)) {
                return response.data;
            }
            if (Array.isArray(response.data?.content)) {
                return response.data.content;
            }
            throw new Error("An employee page did not contain a valid employee list.");
        }),
    ];
};

export const getMyProfile = () =>
    api.get("/employees/my-profile");

export const addEmployee = (employee) =>
    api.post("/employees", employee);

export const updateEmployee = (employee) =>
    api.put(`/employees/${employee.id}`, employee);

export const deleteEmployee = (id) =>
    api.delete(`/employees/${id}`);

export const refreshEmployees = () =>
    api.get("/employees/refresh");