import api from "../api/axios";

export const getBooks = () => api.get("/books");

export const getBookByBarcode = (barcode) =>
    api.get(`/books/barcode/${encodeURIComponent(barcode)}`);

export const createBook = (book) => api.post("/books", book);

export const updateBook = (id, book) => api.put(`/books/${id}`, book);

export const deleteBook = (id) => api.delete(`/books/${id}`);

export const issueBook = (employeeId, barcode) =>
    api.post("/book-transactions/issue", null, {
        params: { employeeId, barcode },
    });

export const returnBook = (barcode) =>
    api.post("/book-transactions/return", null, {
        params: { barcode },
    });

export const getTransactions = () => api.get("/book-transactions");

export const getEmployeeTransactions = (employeeId) =>
    api.get(`/book-transactions/employee/${encodeURIComponent(employeeId)}`);

export const getEmployeeByQrToken = (qrToken) =>
    api.get(`/employees/qr/${encodeURIComponent(qrToken)}`);

export function getLibraryErrorMessage(error, fallback = "Library request failed.") {
    const status = error?.response?.status;
    const responseData = error?.response?.data;
    const serverMessage = typeof responseData === "string"
        ? responseData
        : responseData?.message || responseData?.error;

    if (status === 401) return "Your session has expired. Please sign in again.";
    if (status === 403) return "You do not have permission to perform this action.";
    if (status === 404) return "The requested library record was not found.";
    if (status === 400) return serverMessage || "The request could not be processed. Check the entered details.";
    if (status >= 500) return "The library service is temporarily unavailable. Please try again.";

    return serverMessage || error?.message || fallback;
}
