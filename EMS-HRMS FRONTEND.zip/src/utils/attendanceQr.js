export const ATTENDANCE_QR_TYPE = "EMS_ATTENDANCE";

export function createAttendanceQrPayload({ email, action, expiresInSeconds = 60 }) {
    const cleanEmail = String(email || "").trim();
    const cleanAction = String(action || "").trim().toUpperCase();

    if (!cleanEmail) {
        throw new Error("Employee email is required.");
    }

    if (!["CHECK_IN", "CHECK_OUT"].includes(cleanAction)) {
        throw new Error("Invalid attendance action.");
    }

    const issuedAt = Date.now();
    const expiresAt = issuedAt + Number(expiresInSeconds || 60) * 1000;

    return {
        type: ATTENDANCE_QR_TYPE,
        email: cleanEmail,
        action: cleanAction,
        issuedAt,
        expiresAt,
    };
}

export function buildAttendanceQrUrl({ email, action, expiresInSeconds = 60 }) {
    const payload = createAttendanceQrPayload({ email, action, expiresInSeconds });
    const encodedData = encodeURIComponent(JSON.stringify(payload));
    const baseUrl = import.meta.env.VITE_PUBLIC_APP_URL || window.location.origin;

    return `${baseUrl.replace(/\/$/, "")}/qr-attendance?data=${encodedData}`;
}

export function parseAttendanceQrPayload(value) {
    if (!value) return null;

    try {
        let rawData = value;

        if (typeof value === "string") {
            const trimmedValue = value.trim();

            if (/^https?:\/\//i.test(trimmedValue)) {
                rawData = new URL(trimmedValue).searchParams.get("data");

                if (!rawData) {
                    return null;
                }
            }
        }

        let payload = rawData;

        if (typeof rawData === "string") {
            try {
                payload = JSON.parse(rawData);
            } catch {
                payload = JSON.parse(decodeURIComponent(rawData));
            }
        }

        if (payload?.type !== ATTENDANCE_QR_TYPE) {
            return null;
        }

        const email = String(payload.email || "").trim();
        const action = String(payload.action || "").trim().toUpperCase();
        const expiresAt = Number(payload.expiresAt || 0);
        const issuedAt = Number(payload.issuedAt || 0);

        if (!email || !["CHECK_IN", "CHECK_OUT"].includes(action)) {
            return null;
        }

        const expired = !expiresAt || Date.now() > expiresAt;

        return {
            type: payload.type,
            email,
            action,
            issuedAt,
            expiresAt,
            expired,
        };
    } catch (error) {
        console.error("Invalid attendance QR:", error);
        return null;
    }
}
